function lambda(input, callback) {

    callback(null, undefined);
}