export function agentTransfer() {
    return [
        {
                "type": "message",
                "text": "This option transfers the conversation to the particular agent matching the provided agentId and skill. If the agent is not available, the conversation will be transferred to an available agent with the same skill."
        },
        {
                "type": "message",
                "text": "You will be transferred to a specific skill and agent."
        },
        {
                "type": "message",
                "text": "",
                "channelData": {
                        "action": {
                                "name": "TRANSFER",
                                "parameters": {
                                        "skill": "SpecificAgentSkill",
                                        "agentId": "1005369632"
                                }
                        }
                }
        }
]
}


export function apple() {
    return [
        {
                "type": "message",
                "text": "Which type of Rich Content do you want to see?"
        },
        {
                "type": "message",
                "text": "Please type in list picker, time picker, apple pay, apple auth, apple rich links or custom interactive message."
        }
]
}


export function appleAuth() {
    return [
        {
                "type": "message",
                "text": "The Apple Business Chat messaging channel now allows you to send an authentication request to consumers (only from iOS 12 onwards) using an OAuth 2.0 provider. The consumers then respond to the authentication request with their user/password credentials which can be validated against the OAuth 2.0 provider."
        },
        {
                "type": "message",
                "text": "Please note that the requestIdentifier field must be unique for each message. Therefore, you should replace the requestIdentifier before testing. You will also need your own public key."
        },
        {
                "type": "message",
                "text": "See the following example:"
        },
        {
                "type": "message",
                "text": "",
                "channelData": {
                        "metadata": [
                                {
                                        "type": "BusinessChatMessage",
                                        "receivedMessage": {
                                                "title": "Sign In to LivePerson",
                                                "subtitle": "Thank you",
                                                "imageURL": "https://www.liveperson.com/sites/default/files/pictures/nav/Logo-LP-White.png",
                                                "style": "small"
                                        },
                                        "replyMessage": {
                                                "title": "You Signed in",
                                                "subtitle": "Thank you",
                                                "imageURL": "https://www.liveperson.com/sites/default/files/pictures/nav/Logo-LP-White.png",
                                                "style": "small"
                                        }
                                },
                                {
                                        "type": "ConnectorAuthenticationRequest",
                                        "requestIdentifier": "72af1629-54f1-4dba-a0f6-90f606896bd5",
                                        "apple": {
                                                "oauth2": {
                                                        "responseEncryptionKey": "AAAAC3NzaC1lZDI1NTE5AAAAIPQwXxHgHXafKYObBs6n45BKtMlPCAa1ddeIYqWTMigh"
                                                }
                                        }
                                }
                        ],
                        "structuredContent": {
                                "tag": "authentication",
                                "type": "horizontal",
                                "elements": [
                                        {
                                                "type": "image",
                                                "url": "https://i.imgur.com/8meDl0W.jpeg"
                                        },
                                        {
                                                "type": "text",
                                                "text": "authentication details"
                                        }
                                ]
                        }
                }
        },
        {
                "type": "message",
                "text": "In what else are you interested?"
        }
]
}


export function appleCustomInteractiveMessage() {
    return [
        {
                "type": "message",
                "text": "The Custom Interactive Message (CIM) Template for Apple Business Chat allows you to invoke an iOS iMessage app / extension on the consumer device. This app can allow for a wide range of interactivity without requiring the consumer to leave the conversation."
        },
        {
                "type": "message",
                "text": "For how to create an iMessage app / extension, see the Apple documentation (https://developer.apple.com/imessage/)"
        },
        {
                "type": "message",
                "text": "This template is not covered here as it requires its own IMessage app or extension. More information at the following link."
        },
        {
                "type": "message",
                "text": "",
                "channelData": {
                        "metadata": [],
                        "structuredContent": {
                                "type": "vertical",
                                "tag": "richLink",
                                "elements": [
                                        {
                                                "type": "image",
                                                "url": "https://i.imgur.com/8meDl0W.jpeg"
                                        },
                                        {
                                                "type": "button",
                                                "title": "Custom Interactive Message Template",
                                                "click": {
                                                        "actions": [
                                                                {
                                                                        "type": "link",
                                                                        "uri": "https://developers.liveperson.com/apple-business-chat-templates-custom-interactive-message-template.html"
                                                                }
                                                        ]
                                                }
                                        }
                                ]
                        }
                }
        },
        {
                "type": "message",
                "text": "In what else are you interested?"
        }
]
}


export function appleListPicker() {
    return [
        {
                "type": "message",
                "text": "Business Chat List Picker enables human or automated agents to share a list of items and information about them while allowing the consumer to select multiple items and reply back with the selection. Using metadata properties, brands can define the received and reply bubble structures and enable multi-selection capabilities."
        },
        {
                "type": "message",
                "text": "",
                "channelData": {
                        "metadata": [
                                {
                                        "replyMessage": {
                                                "secondarySubtitle": "secondarySubtitle",
                                                "imageURL": "https://i.imgur.com/8meDl0W.jpeg",
                                                "tertiarySubtitle": "tertiarySubtitle",
                                                "subtitle": "",
                                                "title": "Your selection",
                                                "style": "large"
                                        },
                                        "multipleSelection": [
                                                true,
                                                false
                                        ],
                                        "type": "BusinessChatMessage",
                                        "receivedMessage": {
                                                "tertiarySubtitle": "tertiarySubtitle",
                                                "imageURL": "https://i.imgur.com/8meDl0W.jpeg",
                                                "subtitle": "Select your company",
                                                "secondarySubtitle": "secondary subtitle",
                                                "style": "icon",
                                                "title": "Two companies"
                                        }
                                }
                        ],
                        "structuredContent": {
                                "elements": [
                                        {
                                                "elements": [
                                                        {
                                                                "text": "Company",
                                                                "tooltip": "text tooltip",
                                                                "type": "text",
                                                                "style": {
                                                                        "size": "large",
                                                                        "bold": true
                                                                }
                                                        },
                                                        {
                                                                "type": "horizontal",
                                                                "elements": [
                                                                        {
                                                                                "type": "image",
                                                                                "url": "https://i.imgur.com/8meDl0W.jpeg",
                                                                                "tooltip": "LivePerson"
                                                                        },
                                                                        {
                                                                                "type": "vertical",
                                                                                "elements": [
                                                                                        {
                                                                                                "type": "text",
                                                                                                "tag": "title",
                                                                                                "tooltip": "LivePerson",
                                                                                                "text": "LivePerson",
                                                                                                "style": {
                                                                                                        "size": "large",
                                                                                                        "bold": true
                                                                                                }
                                                                                        },
                                                                                        {
                                                                                                "tag": "subtitle",
                                                                                                "tooltip": "LivePerson",
                                                                                                "text": "The First AI-powered Conversational Cloud",
                                                                                                "type": "text"
                                                                                        },
                                                                                        {
                                                                                                "title": "Select",
                                                                                                "click": {
                                                                                                        "metadata": [],
                                                                                                        "actions": [
                                                                                                                {
                                                                                                                        "text": "LivePerson",
                                                                                                                        "type": "publishText"
                                                                                                                }
                                                                                                        ]
                                                                                                },
                                                                                                "type": "button",
                                                                                                "tooltip": "Select"
                                                                                        }
                                                                                ]
                                                                        }
                                                                ]
                                                        },
                                                        {
                                                                "type": "horizontal",
                                                                "elements": [
                                                                        {
                                                                                "url": "https://bellaloves.me/wp-content/uploads/2021/05/share-bella.jpg",
                                                                                "tooltip": "Bella",
                                                                                "type": "image"
                                                                        },
                                                                        {
                                                                                "elements": [
                                                                                        {
                                                                                                "tag": "title",
                                                                                                "tooltip": "Bella",
                                                                                                "style": {
                                                                                                        "size": "large",
                                                                                                        "bold": true
                                                                                                },
                                                                                                "type": "text",
                                                                                                "text": "Bella"
                                                                                        },
                                                                                        {
                                                                                                "tag": "subtitle",
                                                                                                "tooltip": "Bella",
                                                                                                "text": "Bella loves me",
                                                                                                "type": "text"
                                                                                        },
                                                                                        {
                                                                                                "tooltip": "Select",
                                                                                                "title": "Select",
                                                                                                "type": "button",
                                                                                                "click": {
                                                                                                        "actions": [
                                                                                                                {
                                                                                                                        "type": "publishText",
                                                                                                                        "text": "Bella"
                                                                                                                }
                                                                                                        ]
                                                                                                }
                                                                                        }
                                                                                ],
                                                                                "type": "vertical"
                                                                        }
                                                                ]
                                                        }
                                                ],
                                                "type": "vertical"
                                        }
                                ],
                                "type": "vertical",
                                "tag": "list"
                        }
                }
        }
]
}


export function applePay() {
    return [
        {
                "type": "message",
                "text": "The Apple Business Chat messaging channel now supports a new Rich Message type that allows you to submit payment requests to consumers using Apple Pay. The consumers can then respond to the payment request using their preferred Apple Pay payment methods."
        },
        {
                "type": "message",
                "text": "Unfortunately, it is not possible to add and test Apple Pay in a test account. Below is the link to the documentation and a screenshot of what Apple Pay looks like."
        },
        {
                "type": "message",
                "text": "",
                "channelData": {
                        "metadata": [],
                        "structuredContent": {
                                "type": "vertical",
                                "tag": "richLink",
                                "elements": [
                                        {
                                                "type": "image",
                                                "url": "https://developers.liveperson.com/img/apple_pay_consumer1.png"
                                        },
                                        {
                                                "type": "button",
                                                "title": "Documentation",
                                                "click": {
                                                        "actions": [
                                                                {
                                                                        "type": "link",
                                                                        "uri": "https://developers.liveperson.com/apple-business-chat-templates-apple-pay-template.html"
                                                                }
                                                        ]
                                                }
                                        }
                                ]
                        }
                }
        },
        {
                "type": "message",
                "text": "In what else are you interested?"
        }
]
}


export function appleRichLinks() {
    return [
        {
                "type": "message",
                "text": "Apple has provided a new type of message that allows you to send rich links to the consumer device. Rich link configurable content includes: Bubble title text, link preview image and a link button URL."
        },
        {
                "type": "message",
                "text": "See the following example:"
        },
        {
                "type": "message",
                "text": "",
                "channelData": {
                        "metadata": [],
                        "structuredContent": {
                                "type": "vertical",
                                "tag": "richLink",
                                "elements": [
                                        {
                                                "type": "image",
                                                "url": "https://i.imgur.com/8meDl0W.jpeg"
                                        },
                                        {
                                                "type": "button",
                                                "title": "LivePerson",
                                                "click": {
                                                        "actions": [
                                                                {
                                                                        "type": "link",
                                                                        "uri": "https://liveperson.com"
                                                                }
                                                        ]
                                                }
                                        }
                                ]
                        }
                }
        },
        {
                "type": "message",
                "text": "What else are you interested in?"
        }
]
}


export function appleTimePicker() {
    return [
        {
                "type": "message",
                "text": "Business Chat Time Picker enables human or automated agents to send available time slots when consumers are looking to schedule an appointment with the brand’s various services. Time picker allows the consumer to select the relevant time slot, and reply back with the time selected."
        },
        {
                "type": "message",
                "text": "",
                "channelData": {
                        "metadata": [
                                {
                                        "location": {
                                                "la": 49.4872955,
                                                "radius": 10,
                                                "lo": 8.4682869,
                                                "title": "LivePerson ATC Mannheim"
                                        },
                                        "type": "BusinessEvent",
                                        "title": "Technician Visit",
                                        "timing": {
                                                "presentedTimezoneOffset": 120
                                        }
                                },
                                {
                                        "replyMessage": {
                                                "subtitle": "Time selected!",
                                                "style": "large",
                                                "title": "Selected time",
                                                "imageURL": "https://cdn.dribbble.com/users/85668/screenshots/1352116/dribblble_mock_1x.jpg"
                                        },
                                        "type": "BusinessChatMessage",
                                        "receivedMessage": {
                                                "imageURL": "https://cdn.dribbble.com/users/85668/screenshots/1352116/dribblble_mock_1x.jpg",
                                                "style": "small",
                                                "title": "Available appointments",
                                                "subtitle": "Please select your preferred time"
                                        }
                                }
                        ],
                        "structuredContent": {
                                "elements": [
                                        {
                                                "text": "Select Date",
                                                "style": {
                                                        "bold": true,
                                                        "size": "large"
                                                },
                                                "type": "text",
                                                "tag": "Title"
                                        },
                                        {
                                                "text": "Tuesday, December 12",
                                                "type": "text"
                                        },
                                        {
                                                "type": "horizontal",
                                                "elements": [
                                                        {
                                                                "title": "11:30",
                                                                "click": {
                                                                        "metadata": [
                                                                                {
                                                                                        "type": "ExternalId",
                                                                                        "id": "SlotIdentidier"
                                                                                },
                                                                                {
                                                                                        "timing": {
                                                                                                "duration": 3600,
                                                                                                "startTime": "2023-12-12T11:30:00Z"
                                                                                        },
                                                                                        "type": "BusinessEvent"
                                                                                }
                                                                        ],
                                                                        "actions": [
                                                                                {
                                                                                        "type": "publishText",
                                                                                        "text": "Technician visit: 12/12/2023 11:30 IST"
                                                                                }
                                                                        ]
                                                                },
                                                                "type": "button"
                                                        },
                                                        {
                                                                "title": "12:00",
                                                                "type": "button",
                                                                "click": {
                                                                        "actions": [
                                                                                {
                                                                                        "text": "Technician visit: 12/12/2023 12:00 IST",
                                                                                        "type": "publishText"
                                                                                }
                                                                        ],
                                                                        "metadata": [
                                                                                {
                                                                                        "id": "SlotIdentidier",
                                                                                        "type": "ExternalId"
                                                                                },
                                                                                {
                                                                                        "timing": {
                                                                                                "duration": 3600,
                                                                                                "startTime": "2023-12-12T12:00:00Z"
                                                                                        },
                                                                                        "type": "BusinessEvent"
                                                                                }
                                                                        ]
                                                                }
                                                        }
                                                ]
                                        }
                                ],
                                "tag": "datePicker",
                                "type": "vertical"
                        }
                }
        },
        {
                "type": "message",
                "text": "In what else are you interested?"
        }
]
}


export function endConversation() {
    return [
        {
                "type": "message",
                "text": "The action \"conversation closed\" was triggered."
        },
        {
                "type": "message",
                "text": "Thanks for trying out the Rich Content and Vendor Actions. Goodbye."
        },
        {
                "type": "message",
                "text": "",
                "channelData": {
                        "action": {
                                "name": "CLOSE_CONVERSATION"
                        }
                }
        }
]
}


export function delayPauseConversation() {
    return [
        {
                "type": "message",
                "text": "It is possible to send an event of type \"delay\" before regular content events and actions. This specifies the time the bot will wait before displaying the next message. The delay is given in seconds and typing means if typing indicator while delay is happening."
        },
        {
                "type": "message",
                "text": "This message is sent before the 2 seconds delay."
        },
        {
                "type": "message",
                "text": "",
                "channelData": {
                        "delay": {
                                "delay": 2,
                                "typing": true
                        }
                }
        },
        {
                "type": "message",
                "text": "This message is sent after 2 seconds delay."
        },
        {
                "type": "message",
                "text": "",
                "channelData": {
                        "metadata": [],
                        "structuredContent": {
                                "quickReplies": {
                                        "type": "quickReplies",
                                        "itemsPerRow": 8,
                                        "replies": [
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Vendor Actions",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "Vendor Actions"
                                                                        }
                                                                ],
                                                                "metadata": []
                                                        }
                                                },
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Rich Content",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "Rich Content"
                                                                        }
                                                                ],
                                                                "metadata": []
                                                        }
                                                }
                                        ]
                                },
                                "message": "In what else are you interested?"
                        }
                }
        }
]
}


export function encodedMetadata() {
    return [
        {
                "type": "message",
                "text": "The Conversational Cloud Messaging platform provides a new metadata input type (“encodedMetadata”) for passing a base64 encoded metadata on a conversation. The new metadata input type is in addition to the existing conversation metadata input field."
        },
        {
                "type": "message",
                "text": "To use the feature please reach out to a LivePerson employee."
        },
        {
                "type": "message",
                "text": "Hello I am a text response with encoded metadata!",
                "channelData": {
                        "encodedMetadata": "ewoic29tZUluZm8iOiAiSSB3YXMgZW5jb2RlZCIKfQ=="
                }
        },
        {
                "type": "message",
                "text": "",
                "channelData": {
                        "metadata": [],
                        "structuredContent": {
                                "quickReplies": {
                                        "type": "quickReplies",
                                        "itemsPerRow": 8,
                                        "replies": [
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Vendor Actions",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "Vendor Actions"
                                                                        }
                                                                ],
                                                                "metadata": []
                                                        }
                                                },
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Rich Content",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "Rich Content"
                                                                        }
                                                                ],
                                                                "metadata": []
                                                        }
                                                }
                                        ]
                                },
                                "message": "In what else are you interested?"
                        }
                }
        }
]
}


export function facebook() {
    return [
        {
                "type": "message",
                "text": "",
                "channelData": {
                        "metadata": [],
                        "structuredContent": {
                                "quickReplies": {
                                        "type": "quickReplies",
                                        "itemsPerRow": 8,
                                        "replies": [
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Generic",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "Generic"
                                                                        }
                                                                ],
                                                                "metadata": []
                                                        }
                                                },
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Carousel",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "Carousel"
                                                                        }
                                                                ],
                                                                "metadata": []
                                                        }
                                                },
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Button",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "Button"
                                                                        }
                                                                ],
                                                                "metadata": []
                                                        }
                                                },
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Quick Replies",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "Quick Replies"
                                                                        }
                                                                ],
                                                                "metadata": []
                                                        }
                                                }
                                        ]
                                },
                                "message": "Which type of rich content do you want to see?"
                        }
                }
        }
]
}


export function facebookButton() {
    return [
        {
                "type": "message",
                "text": "The Button template is a simple structured card message that includes a title and up to 3 buttons (link, publish text or navigation)."
        },
        {
                "type": "message",
                "text": "See the following example:"
        },
        {
                "type": "message",
                "text": "",
                "channelData": {
                        "metadata": [],
                        "structuredContent": {
                                "type": "vertical",
                                "tag": "button",
                                "elements": [
                                        {
                                                "type": "vertical",
                                                "elements": [
                                                        {
                                                                "type": "text",
                                                                "tag": "title",
                                                                "text": "Title",
                                                                "tooltip": "Button Title"
                                                        },
                                                        {
                                                                "type": "button",
                                                                "tooltip": "URL example",
                                                                "title": "URL button example",
                                                                "click": {
                                                                        "actions": [
                                                                                {
                                                                                        "type": "link",
                                                                                        "name": "URL button tap",
                                                                                        "uri": "https://www.liveperson.com"
                                                                                }
                                                                        ]
                                                                }
                                                        },
                                                        {
                                                                "type": "button",
                                                                "title": "Navigate",
                                                                "click": {
                                                                        "actions": [
                                                                                {
                                                                                        "type": "navigate",
                                                                                        "lo": 40.7562,
                                                                                        "la": -73.99861
                                                                                }
                                                                        ]
                                                                }
                                                        },
                                                        {
                                                                "type": "button",
                                                                "tooltip": "Publish text example",
                                                                "title": "Back to RC Selection",
                                                                "click": {
                                                                        "actions": [
                                                                                {
                                                                                        "type": "publishText",
                                                                                        "text": "Facebook"
                                                                                }
                                                                        ]
                                                                }
                                                        }
                                                ]
                                        }
                                ]
                        }
                }
        },
        {
                "type": "message",
                "text": "",
                "channelData": {
                        "metadata": [],
                        "structuredContent": {
                                "quickReplies": {
                                        "type": "quickReplies",
                                        "itemsPerRow": 8,
                                        "replies": [
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Generic",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "Generic"
                                                                        }
                                                                ],
                                                                "metadata": []
                                                        }
                                                },
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Carousel",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "Carousel"
                                                                        }
                                                                ],
                                                                "metadata": []
                                                        }
                                                },
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Vendor Actions",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "Vendor Actions"
                                                                        }
                                                                ],
                                                                "metadata": []
                                                        }
                                                }
                                        ]
                                },
                                "message": "In what else are you interested?"
                        }
                }
        }
]
}


export function facebookCarousel() {
    return [
        {
                "type": "message",
                "text": "The Carousel template is a horizontally scrollable carousel of generic or button templates. The carousel includes a list of up to 10 generic or button cards that each can include: Title, subtitle, image and up to 3 buttons (publish text, link or navigation)"
        },
        {
                "type": "message",
                "text": "See the following example:"
        },
        {
                "type": "message",
                "text": "",
                "channelData": {
                        "metadata": [],
                        "structuredContent": {
                                "type": "carousel",
                                "elements": [
                                        {
                                                "type": "vertical",
                                                "tag": "generic",
                                                "elements": [
                                                        {
                                                                "type": "vertical",
                                                                "elements": [
                                                                        {
                                                                                "type": "image",
                                                                                "tooltip": "",
                                                                                "url": "https://i.imgur.com/8meDl0W.jpeg"
                                                                        },
                                                                        {
                                                                                "type": "text",
                                                                                "tag": "title",
                                                                                "text": "LivePerson Homepage",
                                                                                "tooltip": ""
                                                                        },
                                                                        {
                                                                                "type": "button",
                                                                                "title": "Follow Link",
                                                                                "click": {
                                                                                        "actions": [
                                                                                                {
                                                                                                        "type": "link",
                                                                                                        "uri": "https://www.liveperson.com"
                                                                                                }
                                                                                        ]
                                                                                },
                                                                                "tooltip": ""
                                                                        }
                                                                ]
                                                        }
                                                ]
                                        },
                                        {
                                                "type": "vertical",
                                                "tag": "generic",
                                                "elements": [
                                                        {
                                                                "type": "vertical",
                                                                "elements": [
                                                                        {
                                                                                "type": "image",
                                                                                "tooltip": "",
                                                                                "url": "https://bellaloves.me/wp-content/uploads/2021/05/share-bella.jpg"
                                                                        },
                                                                        {
                                                                                "type": "text",
                                                                                "tooltip": "",
                                                                                "tag": "title",
                                                                                "text": "Bella Homepage"
                                                                        },
                                                                        {
                                                                                "type": "button",
                                                                                "title": "Follow link",
                                                                                "click": {
                                                                                        "actions": [
                                                                                                {
                                                                                                        "type": "link",
                                                                                                        "uri": "https://www.bellaloves.me/"
                                                                                                }
                                                                                        ]
                                                                                },
                                                                                "tooltip": ""
                                                                        }
                                                                ]
                                                        }
                                                ]
                                        }
                                ]
                        }
                }
        },
        {
                "type": "message",
                "text": "",
                "channelData": {
                        "metadata": [],
                        "structuredContent": {
                                "quickReplies": {
                                        "type": "quickReplies",
                                        "itemsPerRow": 8,
                                        "replies": [
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Button",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "Button"
                                                                        }
                                                                ],
                                                                "metadata": []
                                                        }
                                                },
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Generic",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "Generic"
                                                                        }
                                                                ],
                                                                "metadata": []
                                                        }
                                                },
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Vendor Actions",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "Vendor Actions"
                                                                        }
                                                                ],
                                                                "metadata": []
                                                        }
                                                }
                                        ]
                                },
                                "message": "In what else are you interested?"
                        }
                }
        }
]
}


export function facebookGeneric() {
    return [
        {
                "type": "message",
                "text": "The Generic template is a simple structured card message that includes: Title, subtitle, image and up to 3 buttons (publish text, link or navigation)"
        },
        {
                "type": "message",
                "text": "See the following example:"
        },
        {
                "type": "message",
                "text": "",
                "channelData": {
                        "metadata": [],
                        "structuredContent": {
                                "type": "vertical",
                                "tag": "generic",
                                "elements": [
                                        {
                                                "type": "vertical",
                                                "elements": [
                                                        {
                                                                "type": "image",
                                                                "url": "https://i.imgur.com/8meDl0W.jpeg",
                                                                "tooltip": "LivePerson"
                                                        },
                                                        {
                                                                "type": "text",
                                                                "tag": "title",
                                                                "text": "LivePerson",
                                                                "tooltip": "Title"
                                                        },
                                                        {
                                                                "type": "text",
                                                                "tag": "subtitle",
                                                                "text": "Connecting Brands to people",
                                                                "tooltip": "subtitle"
                                                        },
                                                        {
                                                                "type": "button",
                                                                "tooltip": "",
                                                                "title": "Publish text example",
                                                                "click": {
                                                                        "actions": [
                                                                                {
                                                                                        "type": "publishText",
                                                                                        "text": "Publish text example"
                                                                                }
                                                                        ]
                                                                }
                                                        },
                                                        {
                                                                "type": "button",
                                                                "tooltip": "LivePerson Homepage",
                                                                "title": "LivePerson Homepage",
                                                                "click": {
                                                                        "actions": [
                                                                                {
                                                                                        "type": "link",
                                                                                        "name": "URL button tap",
                                                                                        "uri": "https://www.liveperson.com"
                                                                                }
                                                                        ]
                                                                }
                                                        },
                                                        {
                                                                "type": "button",
                                                                "title": "Start Navigation",
                                                                "click": {
                                                                        "actions": [
                                                                                {
                                                                                        "type": "navigate",
                                                                                        "lo": 40.75614,
                                                                                        "la": -73.99924
                                                                                }
                                                                        ]
                                                                }
                                                        }
                                                ]
                                        }
                                ]
                        }
                }
        },
        {
                "type": "message",
                "text": "",
                "channelData": {
                        "metadata": [],
                        "structuredContent": {
                                "quickReplies": {
                                        "type": "quickReplies",
                                        "itemsPerRow": 8,
                                        "replies": [
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Button",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "Button"
                                                                        }
                                                                ],
                                                                "metadata": []
                                                        }
                                                },
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Carousel",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "Carousel"
                                                                        }
                                                                ],
                                                                "metadata": []
                                                        }
                                                },
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Vendor Actions",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "Vendor Actions"
                                                                        }
                                                                ],
                                                                "metadata": []
                                                        }
                                                }
                                        ]
                                },
                                "message": "In what else are you interested?"
                        }
                }
        }
]
}


export function facebookQuickReplies() {
    return [
        {
                "type": "message",
                "text": "The Quick Reply template provides a way to receive consumer input to a question/statement by a set of buttons that each contain a title text and/or emojis. The quick reply options always appear above the message composition in the Facebook Messenger window, and will be published in the conversation thread upon consumer selection."
        },
        {
                "type": "message",
                "text": "Quick Replies for Facebook Messenger includes a set of up to 11 buttons that can each contain a text title and a publish text click action."
        },
        {
                "type": "message",
                "text": "",
                "channelData": {
                        "metadata": [],
                        "structuredContent": {
                                "quickReplies": {
                                        "type": "quickReplies",
                                        "itemsPerRow": 8,
                                        "replies": [
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Generic",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "Generic"
                                                                        }
                                                                ],
                                                                "metadata": []
                                                        }
                                                },
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Carousel",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "Carousel"
                                                                        }
                                                                ],
                                                                "metadata": []
                                                        }
                                                },
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Button",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "Button"
                                                                        }
                                                                ],
                                                                "metadata": []
                                                        }
                                                },
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Vendor Actions",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "Vendor Actions"
                                                                        }
                                                                ],
                                                                "metadata": []
                                                        }
                                                }
                                        ]
                                },
                                "message": "In what else are you interested?"
                        }
                }
        }
]
}


export function gbm() {
    return [
        {
                "type": "message",
                "text": "",
                "channelData": {
                        "metadata": [],
                        "structuredContent": {
                                "quickReplies": {
                                        "type": "quickReplies",
                                        "itemsPerRow": 8,
                                        "replies": [
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Card",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "GBM Card"
                                                                        }
                                                                ]
                                                        }
                                                },
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Carousel",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "GBM Carousel"
                                                                        }
                                                                ]
                                                        }
                                                },
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Quick Replies",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "GBM Quick Replies"
                                                                        }
                                                                ]
                                                        }
                                                }
                                        ]
                                },
                                "message": "Which type of rich content do you want to see?"
                        }
                }
        }
]
}


export function gbmCard() {
    return [
        {
                "type": "message",
                "text": "In Google Business Messages a card has the following structure: Image, title, description and up to 4 buttons."
        },
        {
                "type": "message",
                "text": "See the following example:"
        },
        {
                "type": "message",
                "text": "",
                "channelData": {
                        "metadata": [],
                        "structuredContent": {
                                "type": "vertical",
                                "tag": "generic",
                                "display": {
                                        "size": "tall"
                                },
                                "elements": [
                                        {
                                                "type": "image",
                                                "url": "https://i.imgur.com/8meDl0W.jpeg"
                                        },
                                        {
                                                "type": "text",
                                                "tag": "title",
                                                "text": "LivePerson"
                                        },
                                        {
                                                "type": "text",
                                                "text": "Connecting Brands to people"
                                        },
                                        {
                                                "type": "button",
                                                "title": "Homepage",
                                                "click": {
                                                        "actions": [
                                                                {
                                                                        "type": "link",
                                                                        "uri": "https://www.liveperson.com/"
                                                                }
                                                        ]
                                                }
                                        },
                                        {
                                                "type": "button",
                                                "title": "Navigate",
                                                "click": {
                                                        "actions": [
                                                                {
                                                                        "type": "navigate",
                                                                        "lo": 40.75614,
                                                                        "la": -73.99924
                                                                }
                                                        ]
                                                }
                                        },
                                        {
                                                "type": "button",
                                                "title": "Rich Content",
                                                "click": {
                                                        "actions": [
                                                                {
                                                                        "type": "publishText",
                                                                        "text": "GBM"
                                                                }
                                                        ]
                                                }
                                        },
                                        {
                                                "type": "button",
                                                "title": "Vendor Actions",
                                                "click": {
                                                        "actions": [
                                                                {
                                                                        "type": "publishText",
                                                                        "text": "Vendor Actions"
                                                                }
                                                        ]
                                                }
                                        }
                                ]
                        }
                }
        },
        {
                "type": "message",
                "text": "",
                "channelData": {
                        "delay": {
                                "delay": 2,
                                "typing": true
                        }
                }
        },
        {
                "type": "message",
                "text": "",
                "channelData": {
                        "metadata": [],
                        "structuredContent": {
                                "quickReplies": {
                                        "type": "quickReplies",
                                        "itemsPerRow": 8,
                                        "replies": [
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Carousel",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "GBM Carousel"
                                                                        }
                                                                ]
                                                        }
                                                },
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Vendor Actions",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "Vendor Actions"
                                                                        }
                                                                ]
                                                        }
                                                }
                                        ]
                                },
                                "message": "In what else are you interested?"
                        }
                }
        }
]
}


export function gbmCarousel() {
    return [
        {
                "type": "message",
                "text": "The Google Business Messages (GBM) carousel is a horizontally scrollable carousel of up to 10 rich cards."
        },
        {
                "type": "message",
                "text": "See the following example:"
        },
        {
                "type": "message",
                "text": "",
                "channelData": {
                        "metadata": [],
                        "structuredContent": {
                                "type": "carousel",
                                "elements": [
                                        {
                                                "type": "vertical",
                                                "tag": "generic",
                                                "display": {
                                                        "size": "tall"
                                                },
                                                "elements": [
                                                        {
                                                                "type": "image",
                                                                "url": "https://i.imgur.com/8meDl0W.jpeg"
                                                        },
                                                        {
                                                                "type": "text",
                                                                "tag": "title",
                                                                "text": "LivePerson"
                                                        },
                                                        {
                                                                "type": "text",
                                                                "text": "Connecting Brands to people"
                                                        },
                                                        {
                                                                "type": "button",
                                                                "title": "Homepage",
                                                                "click": {
                                                                        "actions": [
                                                                                {
                                                                                        "type": "link",
                                                                                        "uri": "https://www.liveperson.com/"
                                                                                }
                                                                        ]
                                                                }
                                                        }
                                                ]
                                        },
                                        {
                                                "type": "vertical",
                                                "tag": "generic",
                                                "display": {
                                                        "size": "tall"
                                                },
                                                "elements": [
                                                        {
                                                                "type": "image",
                                                                "url": "https://bellaloves.me/wp-content/uploads/2021/05/share-bella.jpg"
                                                        },
                                                        {
                                                                "type": "text",
                                                                "tag": "title",
                                                                "text": "Bella"
                                                        },
                                                        {
                                                                "type": "text",
                                                                "text": "Bella loves me"
                                                        },
                                                        {
                                                                "type": "button",
                                                                "title": "Homepage",
                                                                "click": {
                                                                        "actions": [
                                                                                {
                                                                                        "type": "link",
                                                                                        "uri": "https://www.liveperson.com/"
                                                                                }
                                                                        ]
                                                                }
                                                        }
                                                ]
                                        }
                                ]
                        }
                }
        },
        {
                "type": "message",
                "text": "",
                "channelData": {
                        "delay": {
                                "delay": 2,
                                "typing": true
                        }
                }
        },
        {
                "type": "message",
                "text": "",
                "channelData": {
                        "metadata": [],
                        "structuredContent": {
                                "quickReplies": {
                                        "type": "quickReplies",
                                        "itemsPerRow": 8,
                                        "replies": [
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Card",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "GBM Card"
                                                                        }
                                                                ]
                                                        }
                                                },
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Vendor Actions",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "Vendor Actions"
                                                                        }
                                                                ]
                                                        }
                                                }
                                        ]
                                },
                                "message": "In what else are you interested?"
                        }
                }
        }
]
}


export function gbmQuickReplies() {
    return [
        {
                "type": "message",
                "text": "The Google Business Messages (GBM) quick reply message consist of up to 13 Buttons that are attached to a regular text message."
        },
        {
                "type": "message",
                "text": "",
                "channelData": {
                        "metadata": [],
                        "structuredContent": {
                                "quickReplies": {
                                        "type": "quickReplies",
                                        "itemsPerRow": 8,
                                        "replies": [
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Carousel",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "GBM Carousel"
                                                                        }
                                                                ]
                                                        }
                                                },
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Card",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "GBM Card"
                                                                        }
                                                                ]
                                                        }
                                                },
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Vendor Actions",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "Vendor Actions"
                                                                        }
                                                                ]
                                                        }
                                                }
                                        ]
                                },
                                "message": "In what else are you interested?"
                        }
                }
        }
]
}


export function invokeFunction() {
    return [
        {
                "type": "message",
                "text": "During a conversation, it is possible to trigger a LivePerson Function that is deployed to the LivePerson Functions (Function as a Service) platform. This provides a way to run custom logic with a bot."
        },
        {
                "type": "message",
                "text": "For more information about the LivePerson Functions possibilities with Third Party Bots please check out the following link https://developers.liveperson.com/third-party-bots-amazon-lex.html#invoke-liveperson-function"
        },
        {
                "type": "message",
                "channelData": {
                        "messageAudience": "AGENTS_AND_MANAGERS"
                }
        },
        {
                "type": "message",
                "text": "",
                "channelData": {
                        "metadata": [],
                        "structuredContent": {
                                "quickReplies": {
                                        "type": "quickReplies",
                                        "itemsPerRow": 8,
                                        "replies": [
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Vendor Actions",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "Vendor Actions"
                                                                        }
                                                                ],
                                                                "metadata": []
                                                        }
                                                },
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Rich Content",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "Rich Content"
                                                                        }
                                                                ],
                                                                "metadata": []
                                                        }
                                                }
                                        ]
                                },
                                "message": "In what else are you interested?"
                        }
                }
        }
]
}


export function line() {
    return [
        {
                "type": "message",
                "text": "",
                "channelData": {
                        "metadata": [],
                        "structuredContent": {
                                "quickReplies": {
                                        "type": "quickReplies",
                                        "itemsPerRow": 8,
                                        "replies": [
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Card",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "Line Card"
                                                                        }
                                                                ],
                                                                "metadata": []
                                                        }
                                                },
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Carousel",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "Line Carousel"
                                                                        }
                                                                ],
                                                                "metadata": []
                                                        }
                                                },
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Quick Replies",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "Line Quick Replies"
                                                                        }
                                                                ],
                                                                "metadata": []
                                                        }
                                                }
                                        ]
                                },
                                "message": "Which type of rich content do you want to see?"
                        }
                }
        }
]
}


export function lineCard() {
    return [
        {
                "type": "message",
                "text": "Use LINE cards to send a message with an image, title, text and multiple buttons with actions.The card contains the following elements: Title, subtitle, image and up to 4 buttons (publish text and link)"
        },
        {
                "type": "message",
                "text": "",
                "channelData": {
                        "metadata": [],
                        "structuredContent": {
                                "type": "vertical",
                                "tag": "generic",
                                "alt": "LivePerson",
                                "elements": [
                                        {
                                                "type": "vertical",
                                                "elements": [
                                                        {
                                                                "type": "image",
                                                                "url": "https://i.imgur.com/8meDl0W.jpeg",
                                                                "tooltip": "LivePerson"
                                                        },
                                                        {
                                                                "type": "text",
                                                                "tag": "title",
                                                                "text": "LivePerson",
                                                                "tooltip": "Title"
                                                        },
                                                        {
                                                                "type": "text",
                                                                "tag": "subtitle",
                                                                "text": "Connecting Brands to people",
                                                                "tooltip": "subtitle"
                                                        },
                                                        {
                                                                "type": "button",
                                                                "tooltip": "",
                                                                "title": "Publish text example",
                                                                "click": {
                                                                        "actions": [
                                                                                {
                                                                                        "type": "publishText",
                                                                                        "text": "Publish text example"
                                                                                }
                                                                        ]
                                                                }
                                                        },
                                                        {
                                                                "type": "button",
                                                                "tooltip": "LivePerson Homepage",
                                                                "title": "LivePerson Homepage",
                                                                "click": {
                                                                        "actions": [
                                                                                {
                                                                                        "type": "link",
                                                                                        "name": "URL button tap",
                                                                                        "uri": "https://www.liveperson.com"
                                                                                }
                                                                        ]
                                                                }
                                                        }
                                                ]
                                        }
                                ]
                        }
                }
        },
        {
                "type": "message",
                "text": "",
                "channelData": {
                        "metadata": [],
                        "structuredContent": {
                                "quickReplies": {
                                        "type": "quickReplies",
                                        "itemsPerRow": 8,
                                        "replies": [
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Carousel",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "Line Carousel"
                                                                        }
                                                                ],
                                                                "metadata": []
                                                        }
                                                },
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Vendor Actions",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "Vendor Actions"
                                                                        }
                                                                ],
                                                                "metadata": []
                                                        }
                                                }
                                        ]
                                },
                                "message": "In what else are you interested?"
                        }
                }
        }
]
}


export function lineCarousel() {
    return [
        {
                "type": "message",
                "text": "The LINE carousel is a horizontally scrollable carousel of up to 10 rich cards. Each card can include the following elements: Title, subtitle, image and up to 3 buttons."
        },
        {
                "type": "message",
                "text": "Please note that the carousel items needs to have the same length."
        },
        {
                "type": "message",
                "text": "",
                "channelData": {
                        "metadata": [],
                        "structuredContent": {
                                "type": "carousel",
                                "padding": 10,
                                "alt": "LivePerson",
                                "elements": [
                                        {
                                                "type": "vertical",
                                                "tag": "generic",
                                                "elements": [
                                                        {
                                                                "type": "vertical",
                                                                "elements": [
                                                                        {
                                                                                "type": "image",
                                                                                "url": "https://i.imgur.com/8meDl0W.jpeg",
                                                                                "tooltip": "LivePerson"
                                                                        },
                                                                        {
                                                                                "type": "text",
                                                                                "tag": "title",
                                                                                "text": "LivePerson"
                                                                        },
                                                                        {
                                                                                "type": "text",
                                                                                "tag": "subtitle",
                                                                                "text": "Custom AI-Powered Messaging",
                                                                                "tooltip": "Custom AI-Powered Messaging"
                                                                        },
                                                                        {
                                                                                "type": "button",
                                                                                "title": "Follow Link",
                                                                                "click": {
                                                                                        "actions": [
                                                                                                {
                                                                                                        "name": "LivePerson HomePage",
                                                                                                        "type": "link",
                                                                                                        "uri": "https://www.liveperson.com"
                                                                                                }
                                                                                        ]
                                                                                }
                                                                        }
                                                                ]
                                                        }
                                                ]
                                        },
                                        {
                                                "type": "vertical",
                                                "tag": "generic",
                                                "elements": [
                                                        {
                                                                "type": "vertical",
                                                                "elements": [
                                                                        {
                                                                                "type": "image",
                                                                                "url": "https://bellaloves.me/wp-content/uploads/2021/05/share-bella.jpg",
                                                                                "tooltip": "Bella"
                                                                        },
                                                                        {
                                                                                "type": "text",
                                                                                "tag": "title",
                                                                                "text": "Bella"
                                                                        },
                                                                        {
                                                                                "type": "text",
                                                                                "tag": "subtitle",
                                                                                "text": "Bella loves me"
                                                                        },
                                                                        {
                                                                                "type": "button",
                                                                                "title": "Follow Link",
                                                                                "click": {
                                                                                        "actions": [
                                                                                                {
                                                                                                        "type": "link",
                                                                                                        "name": "Flowers",
                                                                                                        "uri": "https://bellaloves.me"
                                                                                                }
                                                                                        ]
                                                                                }
                                                                        }
                                                                ]
                                                        }
                                                ]
                                        }
                                ]
                        }
                }
        },
        {
                "type": "message",
                "text": "",
                "channelData": {
                        "metadata": [],
                        "structuredContent": {
                                "quickReplies": {
                                        "type": "quickReplies",
                                        "itemsPerRow": 8,
                                        "replies": [
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Card",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "Line Card"
                                                                        }
                                                                ],
                                                                "metadata": []
                                                        }
                                                },
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Vendor Actions",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "Vendor Actions"
                                                                        }
                                                                ],
                                                                "metadata": []
                                                        }
                                                }
                                        ]
                                },
                                "message": "In what else are you interested?"
                        }
                }
        }
]
}


export function lineQR() {
    return [
        {
                "type": "message",
                "text": "When a user receives a message that contains quick reply buttons from a brand, those buttons appear at the bottom of the chat screen on LINE messenger. The user can simply tap one of the buttons to reply to the brand, the response will be captured and shared back to the agent."
        },
        {
                "type": "message",
                "text": "A LINE quick reply button consists of the question/statement text and a set of up to 13 buttons and that each contain: Title text (including emojis) or publish text click action."
        },
        {
                "type": "message",
                "text": "",
                "channelData": {
                        "metadata": [],
                        "structuredContent": {
                                "quickReplies": {
                                        "type": "quickReplies",
                                        "itemsPerRow": 8,
                                        "replies": [
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Carousel",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "Line Carousel"
                                                                        }
                                                                ],
                                                                "metadata": []
                                                        }
                                                },
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Card",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "Line Card"
                                                                        }
                                                                ],
                                                                "metadata": []
                                                        }
                                                },
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Vendor Actions",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "Vendor Actions"
                                                                        }
                                                                ],
                                                                "metadata": []
                                                        }
                                                }
                                        ]
                                },
                                "message": "In what else are you interested?"
                        }
                }
        }
]
}


export function privateMessage() {
    return [
        {
                "type": "message",
                "text": "In general it is possible for agents in the Conversational Cloud to send each other private text messages. This feature can now be used via the Third-Party bots as well. This will allow Brands to define private message text within the conversational flow of the bot. These messages are published into the conversation for other Agent/Manger participants. This enables Brands to customize messages giving more insight, summarizing actions taken by the bot, or also advising on next actions the handover agent should take."
        },
        {
                "type": "message",
                "text": "Setting a private text message between multiple messages is also possible. Moreover, it is also possible to send a private text message with a combination of actions (e.g. Transfer) as well."
        },
        {
                "type": "message",
                "text": "The private message is not visible in the messenger. You can see the private message in the Conversational Cloud."
        },
        {
                "type": "message",
                "text": "This is a private message for a Conversational Cloud agent from a third party bot.",
                "channelData": {
                        "messageAudience": "AGENTS_AND_MANAGERS"
                }
        },
        {
                "type": "message",
                "text": "",
                "channelData": {
                        "metadata": [],
                        "structuredContent": {
                                "quickReplies": {
                                        "type": "quickReplies",
                                        "itemsPerRow": 8,
                                        "replies": [
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Vendor Actions",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "Vendor Actions"
                                                                        }
                                                                ],
                                                                "metadata": []
                                                        }
                                                },
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Rich Content",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "Rich Content"
                                                                        }
                                                                ],
                                                                "metadata": []
                                                        }
                                                }
                                        ]
                                },
                                "message": "In what else are you interested?"
                        }
                }
        }
]
}


export function rcs() {
    return [
        {
                "type": "message",
                "text": "",
                "channelData": {
                        "metadata": [],
                        "structuredContent": {
                                "quickReplies": {
                                        "type": "quickReplies",
                                        "itemsPerRow": 8,
                                        "replies": [
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Card",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "RCS Card"
                                                                        }
                                                                ],
                                                                "metadata": []
                                                        }
                                                },
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Carousel",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "RCS Carousel"
                                                                        }
                                                                ],
                                                                "metadata": []
                                                        }
                                                },
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Quick Replies",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "RCS Quick Replies"
                                                                        }
                                                                ],
                                                                "metadata": []
                                                        }
                                                }
                                        ]
                                },
                                "message": "Which type of rich content do you want to see?"
                        }
                }
        }
]
}


export function rcsCard() {
    return [
        {
                "type": "message",
                "text": "The RCS Business Messaging card has 2 template orientation options: Vertical and horizontal. Both can contain: Title, subtitle, image and up to 4 buttons (link, navigation and publish text)."
        },
        {
                "type": "message",
                "text": "See following examples:"
        },
        {
                "type": "message",
                "text": "",
                "channelData": {
                        "metadata": [],
                        "structuredContent": {
                                "type": "vertical",
                                "tag": "generic",
                                "elements": [
                                        {
                                                "type": "vertical",
                                                "elements": [
                                                        {
                                                                "type": "image",
                                                                "url": "https://i.imgur.com/8meDl0W.jpeg"
                                                        },
                                                        {
                                                                "type": "text",
                                                                "tag": "title",
                                                                "text": "LivePerson"
                                                        },
                                                        {
                                                                "type": "text",
                                                                "tag": "subtitle",
                                                                "text": "Connecting Brands to people"
                                                        },
                                                        {
                                                                "type": "button",
                                                                "title": "Homepage",
                                                                "click": {
                                                                        "actions": [
                                                                                {
                                                                                        "type": "link",
                                                                                        "uri": "https://www.liveperson.com/"
                                                                                }
                                                                        ]
                                                                }
                                                        },
                                                        {
                                                                "type": "button",
                                                                "title": "Navigate",
                                                                "click": {
                                                                        "actions": [
                                                                                {
                                                                                        "type": "navigate",
                                                                                        "lo": 40.75614,
                                                                                        "la": -73.99924
                                                                                }
                                                                        ]
                                                                }
                                                        },
                                                        {
                                                                "type": "button",
                                                                "title": "Rich Content",
                                                                "click": {
                                                                        "actions": [
                                                                                {
                                                                                        "type": "publishText",
                                                                                        "text": "RCS"
                                                                                }
                                                                        ]
                                                                }
                                                        },
                                                        {
                                                                "type": "button",
                                                                "title": "Vendor Actions",
                                                                "click": {
                                                                        "actions": [
                                                                                {
                                                                                        "type": "publishText",
                                                                                        "text": "Vendor Actions"
                                                                                }
                                                                        ]
                                                                }
                                                        }
                                                ]
                                        }
                                ]
                        }
                }
        },
        {
                "type": "message",
                "text": "",
                "channelData": {
                        "metadata": [],
                        "structuredContent": {
                                "type": "horizontal",
                                "tag": "generic",
                                "elements": [
                                        {
                                                "type": "vertical",
                                                "elements": [
                                                        {
                                                                "type": "image",
                                                                "url": "https://i.imgur.com/8meDl0W.jpeg"
                                                        },
                                                        {
                                                                "type": "text",
                                                                "tag": "title",
                                                                "text": "LivePerson"
                                                        },
                                                        {
                                                                "type": "text",
                                                                "tag": "subtitle",
                                                                "text": "Connecting Brands to people"
                                                        },
                                                        {
                                                                "type": "button",
                                                                "title": "Homepage",
                                                                "click": {
                                                                        "actions": [
                                                                                {
                                                                                        "type": "link",
                                                                                        "uri": "https://www.liveperson.com/"
                                                                                }
                                                                        ]
                                                                }
                                                        },
                                                        {
                                                                "type": "button",
                                                                "title": "Navigate",
                                                                "click": {
                                                                        "actions": [
                                                                                {
                                                                                        "type": "navigate",
                                                                                        "lo": 40.75614,
                                                                                        "la": -73.99924
                                                                                }
                                                                        ]
                                                                }
                                                        },
                                                        {
                                                                "type": "button",
                                                                "title": "Rich Content",
                                                                "click": {
                                                                        "actions": [
                                                                                {
                                                                                        "type": "publishText",
                                                                                        "text": "RCS"
                                                                                }
                                                                        ]
                                                                }
                                                        },
                                                        {
                                                                "type": "button",
                                                                "title": "Vendor Actions",
                                                                "click": {
                                                                        "actions": [
                                                                                {
                                                                                        "type": "publishText",
                                                                                        "text": "Vendor Actions"
                                                                                }
                                                                        ]
                                                                }
                                                        }
                                                ]
                                        }
                                ]
                        }
                }
        },
        {
                "type": "message",
                "text": "",
                "channelData": {
                        "metadata": [],
                        "structuredContent": {
                                "quickReplies": {
                                        "type": "quickReplies",
                                        "itemsPerRow": 8,
                                        "replies": [
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Carousel",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "RCS Carousel"
                                                                        }
                                                                ],
                                                                "metadata": []
                                                        }
                                                },
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Vendor Actions",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "Vendor Actions"
                                                                        }
                                                                ],
                                                                "metadata": []
                                                        }
                                                }
                                        ]
                                },
                                "message": "In what else are you interested in?"
                        }
                }
        }
]
}


export function rcsCarousel() {
    return [
        {
                "type": "message",
                "text": "The RCS carousel is a horizontally scrollable carousel of up to 10 vertical rich cards. Each card can include the following elements: Title, subtitle, image and up to 4 buttons (link, navigation and publish text)."
        },
        {
                "type": "message",
                "text": "",
                "channelData": {
                        "metadata": [],
                        "structuredContent": {
                                "type": "carousel",
                                "padding": 10,
                                "elements": [
                                        {
                                                "type": "vertical",
                                                "tag": "generic",
                                                "elements": [
                                                        {
                                                                "type": "vertical",
                                                                "elements": [
                                                                        {
                                                                                "type": "image",
                                                                                "url": "https://i.imgur.com/8meDl0W.jpeg",
                                                                                "tooltip": "LivePerson"
                                                                        },
                                                                        {
                                                                                "type": "text",
                                                                                "tag": "title",
                                                                                "text": "LivePerson"
                                                                        },
                                                                        {
                                                                                "type": "text",
                                                                                "tag": "subtitle",
                                                                                "text": "Custom AI-Powered Messaging",
                                                                                "tooltip": "Custom AI-Powered Messaging"
                                                                        },
                                                                        {
                                                                                "type": "button",
                                                                                "title": "Follow Link",
                                                                                "click": {
                                                                                        "actions": [
                                                                                                {
                                                                                                        "name": "LivePerson HomePage",
                                                                                                        "type": "link",
                                                                                                        "uri": "https://www.liveperson.com"
                                                                                                }
                                                                                        ]
                                                                                }
                                                                        }
                                                                ]
                                                        }
                                                ]
                                        },
                                        {
                                                "type": "vertical",
                                                "tag": "generic",
                                                "elements": [
                                                        {
                                                                "type": "vertical",
                                                                "elements": [
                                                                        {
                                                                                "type": "image",
                                                                                "url": "https://bellaloves.me/wp-content/uploads/2021/05/share-bella.jpg",
                                                                                "tooltip": "Bella"
                                                                        },
                                                                        {
                                                                                "type": "text",
                                                                                "tag": "title",
                                                                                "text": "Bella"
                                                                        },
                                                                        {
                                                                                "type": "text",
                                                                                "tag": "subtitle",
                                                                                "text": "Bella loves me"
                                                                        },
                                                                        {
                                                                                "type": "button",
                                                                                "title": "Follow Link",
                                                                                "click": {
                                                                                        "actions": [
                                                                                                {
                                                                                                        "type": "link",
                                                                                                        "name": "Flowers",
                                                                                                        "uri": "https://bellaloves.me"
                                                                                                }
                                                                                        ]
                                                                                }
                                                                        }
                                                                ]
                                                        }
                                                ]
                                        }
                                ]
                        }
                }
        },
        {
                "type": "message",
                "text": "",
                "channelData": {
                        "metadata": [],
                        "structuredContent": {
                                "quickReplies": {
                                        "type": "quickReplies",
                                        "itemsPerRow": 8,
                                        "replies": [
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Card",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "RCS Card"
                                                                        }
                                                                ],
                                                                "metadata": []
                                                        }
                                                },
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Vendor Actions",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "Vendor Actions"
                                                                        }
                                                                ],
                                                                "metadata": []
                                                        }
                                                }
                                        ]
                                },
                                "message": "In what else are you interested in?"
                        }
                }
        }
]
}


export function rcsQuickReplies() {
    return [
        {
                "type": "message",
                "text": "Quick Replies for RCS Business Messaging include the question/statement text and a set of up to 11 replies that each contain: Title text (including emojis) or publish text click action."
        },
        {
                "type": "message",
                "text": "",
                "channelData": {
                        "metadata": [],
                        "structuredContent": {
                                "quickReplies": {
                                        "type": "quickReplies",
                                        "itemsPerRow": 8,
                                        "replies": [
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Card",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "RCS Card"
                                                                        }
                                                                ],
                                                                "metadata": []
                                                        }
                                                },
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Carousel",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "RCS Carousel"
                                                                        }
                                                                ],
                                                                "metadata": []
                                                        }
                                                },
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Vendor Actions",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "Vendor Actions"
                                                                        }
                                                                ],
                                                                "metadata": []
                                                        }
                                                }
                                        ]
                                },
                                "message": "In what else are you interested in?"
                        }
                }
        }
]
}


export function richContentSelection() {
    return [
        {
                "type": "message",
                "text": "",
                "channelData": {
                        "metadata": [],
                        "structuredContent": {
                                "quickReplies": {
                                        "type": "quickReplies",
                                        "itemsPerRow": 8,
                                        "replies": [
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Web",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "Web"
                                                                        }
                                                                ]
                                                        }
                                                },
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Facebook",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "Facebook"
                                                                        }
                                                                ]
                                                        }
                                                },
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "WhatsApp",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "WhatsApp"
                                                                        }
                                                                ]
                                                        }
                                                },
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "ABC",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "ABC"
                                                                        }
                                                                ]
                                                        }
                                                },
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "GBM",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "GBM"
                                                                        }
                                                                ]
                                                        }
                                                },
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Google RCS",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "RCS"
                                                                        }
                                                                ]
                                                        }
                                                },
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Line",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "Line"
                                                                        }
                                                                ]
                                                        }
                                                }
                                        ]
                                },
                                "message": "Please select/type the channel you are currently using. A wrong selection can lead to malfunctions of the bot."
                        }
                }
        }
]
}


export function richContentSelectionTextBased() {
    return [
        {
                "type": "message",
                "text": "Which Rich Content would you like to see?"
        },
        {
                "type": "message",
                "text": "The following Rich Contents are available: Web, Apple, WhatsApp, Facebook, Line, GBM and RCS."
        },
        {
                "type": "message",
                "text": "Please note that a wrong selection can lead to malfunctions of the bot."
        }
]
}


export function skillTransfer() {
    return [
        {
                "type": "message",
                "text": "This option transfers the conversation to the next available agent using the provided skill."
        },
        {
                "type": "message",
                "text": "You will be transferred to the given skill."
        },
        {
                "type": "message",
                "text": "",
                "channelData": {
                        "action": {
                                "name": "TRANSFER",
                                "parameters": {
                                        "skill": "AgentSkill"
                                }
                        }
                }
        }
]
}


export function vendorActionSelection() {
    return [
        {
                "type": "message",
                "text": "",
                "channelData": {
                        "metadata": [],
                        "structuredContent": {
                                "quickReplies": {
                                        "type": "quickReplies",
                                        "itemsPerRow": 8,
                                        "replies": [
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Transfer to Agent",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "Transfer to Agent"
                                                                        }
                                                                ],
                                                                "metadata": []
                                                        }
                                                },
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Transfer to Skill",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "Transfer to Skill"
                                                                        }
                                                                ],
                                                                "metadata": []
                                                        }
                                                },
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Delayed Message",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "Delayed Message"
                                                                        }
                                                                ],
                                                                "metadata": []
                                                        }
                                                },
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Close conversation",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "Close conversation"
                                                                        }
                                                                ],
                                                                "metadata": []
                                                        }
                                                },
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "More",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "More Vendor Actions"
                                                                        }
                                                                ],
                                                                "metadata": []
                                                        }
                                                }
                                        ]
                                },
                                "message": "Which Vendor Action would you like to see?"
                        }
                }
        }
]
}


export function vendorActionSelectionMore() {
    return [
        {
                "type": "message",
                "text": "",
                "channelData": {
                        "metadata": [],
                        "structuredContent": {
                                "quickReplies": {
                                        "type": "quickReplies",
                                        "itemsPerRow": 8,
                                        "replies": [
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Encoded Metadata",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "Encoded Metadata"
                                                                        }
                                                                ],
                                                                "metadata": []
                                                        }
                                                },
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Private message",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "Private message"
                                                                        }
                                                                ],
                                                                "metadata": []
                                                        }
                                                },
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Invoke Function",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "Invoke Function"
                                                                        }
                                                                ],
                                                                "metadata": []
                                                        }
                                                },
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Back",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "Back"
                                                                        }
                                                                ],
                                                                "metadata": []
                                                        }
                                                }
                                        ]
                                },
                                "message": "Which Vendor Action would you like to see?"
                        }
                }
        }
]
}


export function vendorActionSelectionTextBased() {
    return [
        {
                "type": "message",
                "text": "Which Vendor Action would you like to see?"
        },
        {
                "type": "message",
                "text": "The following actions are available: Transfer to Agent, Transfer to Skill, Delayed Message, Close Conversation, Encoded Metadata, Private Message and Invoke Function"
        }
]
}


export function web() {
    return [
        {
                "type": "message",
                "text": "",
                "channelData": {
                        "metadata": [],
                        "structuredContent": {
                                "quickReplies": {
                                        "type": "quickReplies",
                                        "itemsPerRow": 8,
                                        "replies": [
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Card",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "Web Card"
                                                                        }
                                                                ]
                                                        }
                                                },
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Carousel",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "Web Carousel"
                                                                        }
                                                                ]
                                                        }
                                                },
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Date Picker",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "Web Date Picker"
                                                                        }
                                                                ]
                                                        }
                                                },
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Schedule Slot List",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "Web Schedule Slot List"
                                                                        }
                                                                ]
                                                        }
                                                },
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Multiple Checklist",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "Web Multiple Checklist"
                                                                        }
                                                                ]
                                                        }
                                                }
                                        ]
                                },
                                "message": "Which type of rich content do you want to see?"
                        }
                }
        }
]
}


export function webCard() {
    return [
        {
                "type": "message",
                "text": "The very basic Rich Content elements that can contain either/or elements, template, styling and actions."
        },
        {
                "type": "message",
                "text": "See the following example:"
        },
        {
                "type": "message",
                "text": "",
                "channelData": {
                        "metadata": [],
                        "structuredContent": {
                                "type": "vertical",
                                "elements": [
                                        {
                                                "type": "image",
                                                "url": "https://i.imgur.com/8meDl0W.jpeg",
                                                "tooltip": "image tooltip"
                                        },
                                        {
                                                "type": "text",
                                                "text": "LivePerson",
                                                "tooltip": "text tooltip"
                                        },
                                        {
                                                "type": "text",
                                                "text": "Connecting Brands to people",
                                                "tooltip": "text tooltip"
                                        },
                                        {
                                                "type": "button",
                                                "tooltip": "LivePerson Homepage",
                                                "title": "LivePerson Homepage",
                                                "click": {
                                                        "actions": [
                                                                {
                                                                        "type": "link",
                                                                        "name": "URL button tap",
                                                                        "uri": "https://www.liveperson.com"
                                                                }
                                                        ]
                                                }
                                        },
                                        {
                                                "type": "button",
                                                "title": "Start Navigation",
                                                "click": {
                                                        "actions": [
                                                                {
                                                                        "type": "navigate",
                                                                        "lo": 40.75614,
                                                                        "la": -73.99924
                                                                }
                                                        ]
                                                }
                                        }
                                ]
                        }
                }
        },
        {
                "type": "message",
                "text": "",
                "channelData": {
                        "metadata": [],
                        "structuredContent": {
                                "quickReplies": {
                                        "type": "quickReplies",
                                        "itemsPerRow": 8,
                                        "replies": [
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Carousel",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "Web Carousel"
                                                                        }
                                                                ]
                                                        }
                                                },
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Date Picker",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "Web Date Picker"
                                                                        }
                                                                ]
                                                        }
                                                },
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Schedule Slot List",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "Web Schedule Slot List"
                                                                        }
                                                                ]
                                                        }
                                                },
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Multiple Checklist",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "Web Multiple Checklist"
                                                                        }
                                                                ]
                                                        }
                                                },
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Vendor Actions",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "Vendor Actions"
                                                                        }
                                                                ]
                                                        }
                                                }
                                        ]
                                },
                                "message": "Which type of rich content do you want to see?"
                        }
                }
        }
]
}


export function webCarousel() {
    return [
        {
                "type": "message",
                "text": "A horizontal representation of 2-10 Rich Content cards of the same business logic and structure. The carousel format can support a variety of businesses and needs to showcase service offerings, events and more."
        },
        {
                "type": "message",
                "text": "See the following example:"
        },
        {
                "type": "message",
                "text": "",
                "channelData": {
                        "metadata": [],
                        "structuredContent": {
                                "type": "carousel",
                                "padding": 10,
                                "elements": [
                                        {
                                                "type": "vertical",
                                                "elements": [
                                                        {
                                                                "type": "image",
                                                                "url": "https://i.imgur.com/8meDl0W.jpeg",
                                                                "tooltip": "image tooltip"
                                                        },
                                                        {
                                                                "type": "text",
                                                                "text": "LivePerson",
                                                                "tooltip": "text tooltip"
                                                        },
                                                        {
                                                                "type": "text",
                                                                "text": "Connecting Brands to people",
                                                                "tooltip": "text tooltip"
                                                        },
                                                        {
                                                                "type": "button",
                                                                "tooltip": "LivePerson Homepage",
                                                                "title": "LivePerson Homepage",
                                                                "click": {
                                                                        "actions": [
                                                                                {
                                                                                        "type": "link",
                                                                                        "name": "URL button tap",
                                                                                        "uri": "https://www.liveperson.com"
                                                                                }
                                                                        ]
                                                                }
                                                        }
                                                ]
                                        },
                                        {
                                                "type": "vertical",
                                                "elements": [
                                                        {
                                                                "type": "image",
                                                                "url": "https://bellaloves.me/wp-content/uploads/2021/05/share-bella.jpg",
                                                                "tooltip": "image tooltip"
                                                        },
                                                        {
                                                                "type": "text",
                                                                "text": "Bella",
                                                                "tooltip": "text tooltip"
                                                        },
                                                        {
                                                                "type": "text",
                                                                "text": "Bella loves me",
                                                                "tooltip": "text tooltip"
                                                        },
                                                        {
                                                                "type": "button",
                                                                "tooltip": "Bella Homepage",
                                                                "title": "Bella Homepage",
                                                                "click": {
                                                                        "actions": [
                                                                                {
                                                                                        "type": "link",
                                                                                        "name": "URL button tap",
                                                                                        "uri": "https://bellaloves.me/"
                                                                                }
                                                                        ]
                                                                }
                                                        }
                                                ]
                                        }
                                ]
                        }
                }
        },
        {
                "type": "message",
                "text": "",
                "channelData": {
                        "metadata": [],
                        "structuredContent": {
                                "quickReplies": {
                                        "type": "quickReplies",
                                        "itemsPerRow": 8,
                                        "replies": [
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Card",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "Web Card"
                                                                        }
                                                                ]
                                                        }
                                                },
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Date Picker",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "Web Date Picker"
                                                                        }
                                                                ]
                                                        }
                                                },
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Schedule Slot List",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "Web Schedule Slot List"
                                                                        }
                                                                ]
                                                        }
                                                },
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Multiple Checklist",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "Web Multiple Checklist"
                                                                        }
                                                                ]
                                                        }
                                                },
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Vendor Actions",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "Vendor Actions"
                                                                        }
                                                                ]
                                                        }
                                                }
                                        ]
                                },
                                "message": "Which type of rich content do you want to see?"
                        }
                }
        }
]
}


export function webDatePicker() {
    return [
        {
                "type": "message",
                "text": "Web Messaging now allows for Date Picker functionality. The Conversational Cloud enables the agent to send a Rich Content button with a date picker action attached. This action will present a graphical user interface widget, which allows the consumer to efficiently select a date or date range."
        },
        {
                "type": "message",
                "text": "Please note that the DatePicker JSON schema is only supported on accounts using UMS version 4.2, please contact your LivePerson representative to validate your account qualifies for this feature."
        },
        {
                "type": "message",
                "text": "See the following example:"
        },
        {
                "type": "message",
                "text": "",
                "channelData": {
                        "metadata": [],
                        "structuredContent": {
                                "type": "vertical",
                                "border": "dropShadow",
                                "elements": [
                                        {
                                                "type": "horizontal",
                                                "borderLine": false,
                                                "percentages": [
                                                        20,
                                                        80
                                                ],
                                                "elements": [
                                                        {
                                                                "type": "image",
                                                                "url": "https://i.imgur.com/8meDl0W.jpeg",
                                                                "tooltip": "image tooltip"
                                                        },
                                                        {
                                                                "type": "vertical",
                                                                "elements": [
                                                                        {
                                                                                "type": "text",
                                                                                "text": "Date Picker",
                                                                                "tooltip": "text tooltip",
                                                                                "style": {
                                                                                        "bold": true,
                                                                                        "size": "large"
                                                                                }
                                                                        },
                                                                        {
                                                                                "type": "text",
                                                                                "text": "Select a date range",
                                                                                "tooltip": "text tooltip"
                                                                        }
                                                                ]
                                                        }
                                                ]
                                        },
                                        {
                                                "type": "button",
                                                "tooltip": "button tooltip",
                                                "title": "Select dates",
                                                "class": "button",
                                                "style": {
                                                        "background-color": "#3736A6",
                                                        "color": "#ffffff",
                                                        "size": "medium",
                                                        "bold": true
                                                },
                                                "click": {
                                                        "actions": [
                                                                {
                                                                        "type": "datePicker",
                                                                        "class": "range",
                                                                        "title": "Select range of date",
                                                                        "minDate": 1618613044,
                                                                        "maxDate": 1634424244,
                                                                        "dateFormat": "DD-MM-YYYY"
                                                                }
                                                        ]
                                                }
                                        }
                                ]
                        }
                }
        },
        {
                "type": "message",
                "text": "",
                "channelData": {
                        "metadata": [],
                        "structuredContent": {
                                "quickReplies": {
                                        "type": "quickReplies",
                                        "itemsPerRow": 8,
                                        "replies": [
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Card",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "Web Card"
                                                                        }
                                                                ]
                                                        }
                                                },
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Date Picker",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "Web Carousel"
                                                                        }
                                                                ]
                                                        }
                                                },
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Schedule Slot List",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "Web Schedule Slot List"
                                                                        }
                                                                ]
                                                        }
                                                },
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Multiple Checklist",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "Web Multiple Checklist"
                                                                        }
                                                                ]
                                                        }
                                                },
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Vendor Actions",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "Vendor Actions"
                                                                        }
                                                                ]
                                                        }
                                                }
                                        ]
                                },
                                "message": "Which type of rich content do you want to see?"
                        }
                }
        }
]
}


export function webFallback() {
    return [
        {
                "type": "message",
                "text": "",
                "channelData": {
                        "metadata": [],
                        "structuredContent": {
                                "quickReplies": {
                                        "type": "quickReplies",
                                        "itemsPerRow": 8,
                                        "replies": [
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Card",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "Web Card"
                                                                        }
                                                                ]
                                                        }
                                                },
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Carousel",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "Web Carousel"
                                                                        }
                                                                ]
                                                        }
                                                },
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Date Picker",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "Web Date Picker"
                                                                        }
                                                                ]
                                                        }
                                                },
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Schedule Slot List",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "Web Schedule Slot List"
                                                                        }
                                                                ]
                                                        }
                                                },
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Multiple Checklist",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "Web Multiple Checklist"
                                                                        }
                                                                ]
                                                        }
                                                }
                                        ]
                                },
                                "message": "In what else are you interested in?"
                        }
                }
        }
]
}


export function webMultipleChecklist() {
    return [
        {
                "type": "message",
                "text": "The Multiple Checklist Template for the Web Messaging channel enables human or bot agents to share a list of items, while allowing the consumer to select multiple items and reply back with the selection."
        },
        {
                "type": "message",
                "text": "See the following example:"
        },
        {
                "type": "message",
                "text": "",
                "channelData": {
                        "metadata": [],
                        "structuredContent": {
                                "type": "list",
                                "elements": [
                                        {
                                                "type": "text",
                                                "text": "Which company are you specifically looking for?"
                                        },
                                        {
                                                "type": "sectionList",
                                                "elements": [
                                                        {
                                                                "type": "section",
                                                                "sectionID": "channels",
                                                                "elements": [
                                                                        {
                                                                                "type": "text",
                                                                                "text": "&#x1F449; choose all that apply"
                                                                        },
                                                                        {
                                                                                "type": "checklist",
                                                                                "elements": [
                                                                                        {
                                                                                                "type": "checkbox",
                                                                                                "text": "LivePerson",
                                                                                                "borderLine": true,
                                                                                                "borderColor": "#d4d4d5",
                                                                                                "click": {
                                                                                                        "metadata": [
                                                                                                                {
                                                                                                                        "type": "ExternalId",
                                                                                                                        "id": "ANOTHER_ONE_35"
                                                                                                                }
                                                                                                        ],
                                                                                                        "actions": [
                                                                                                                {
                                                                                                                        "type": "checked",
                                                                                                                        "publishText": "LivePerson"
                                                                                                                }
                                                                                                        ]
                                                                                                }
                                                                                        },
                                                                                        {
                                                                                                "type": "checkbox",
                                                                                                "text": "Bella",
                                                                                                "borderLine": true,
                                                                                                "borderColor": "#d4d4d5",
                                                                                                "click": {
                                                                                                        "metadata": [
                                                                                                                {
                                                                                                                        "type": "ExternalId",
                                                                                                                        "id": "ANOTHER_ONE_30"
                                                                                                                }
                                                                                                        ],
                                                                                                        "actions": [
                                                                                                                {
                                                                                                                        "type": "checked",
                                                                                                                        "publishText": "Bella"
                                                                                                                }
                                                                                                        ]
                                                                                                }
                                                                                        }
                                                                                ]
                                                                        }
                                                                ]
                                                        }
                                                ]
                                        },
                                        {
                                                "type": "buttonList",
                                                "elements": [
                                                        {
                                                                "type": "submitButton",
                                                                "title": "Continue",
                                                                "disabled": false,
                                                                "click": {
                                                                        "actions": [
                                                                                {
                                                                                        "type": "submitAsText",
                                                                                        "submit": true
                                                                                }
                                                                        ]
                                                                }
                                                        },
                                                        {
                                                                "type": "button",
                                                                "title": "Back",
                                                                "click": {
                                                                        "actions": [
                                                                                {
                                                                                        "type": "publishText",
                                                                                        "text": "web rich content"
                                                                                }
                                                                        ]
                                                                }
                                                        }
                                                ]
                                        }
                                ]
                        }
                }
        }
]
}


export function webScheduleSlotList() {
    return [
        {
                "type": "message",
                "text": "Web Messaging now allows functionality to present Schedule Slot Lists. The Conversational Cloud enables the agent to send a Rich Content button with a Schedule Slot Lists action attached. This action will present a graphical user interface widget, which allows the consumer to efficiently select an appointment slot from a list."
        },
        {
                "type": "message",
                "text": "Please note that the ScheduleSlotList JSON schema is only supported on accounts using UMS version 4.2, please contact your LivePerson representative to validate your account qualifies for this feature."
        },
        {
                "type": "message",
                "text": "",
                "channelData": {
                        "metadata": [],
                        "structuredContent": {
                                "type": "vertical",
                                "border": "dropShadow",
                                "elements": [
                                        {
                                                "type": "horizontal",
                                                "borderLine": false,
                                                "elements": [
                                                        {
                                                                "type": "vertical",
                                                                "elements": [
                                                                        {
                                                                                "type": "text",
                                                                                "text": "Schedule List",
                                                                                "tooltip": "text tooltip",
                                                                                "style": {
                                                                                        "bold": true,
                                                                                        "size": "large"
                                                                                }
                                                                        },
                                                                        {
                                                                                "type": "text",
                                                                                "text": "Select appointment",
                                                                                "tooltip": "text tooltip"
                                                                        }
                                                                ]
                                                        }
                                                ]
                                        },
                                        {
                                                "type": "button",
                                                "tooltip": "button tooltip",
                                                "title": "Select appointment",
                                                "class": "button",
                                                "style": {
                                                        "background-color": "#3736A6",
                                                        "color": "#ffffff",
                                                        "border-radius": 10,
                                                        "border-color": "#000000",
                                                        "size": "medium",
                                                        "bold": true
                                                },
                                                "click": {
                                                        "actions": [
                                                                {
                                                                        "type": "scheduleSlotList",
                                                                        "title": "Schedule your appointment",
                                                                        "firstDayOfTheWeek": "mon",
                                                                        "slots": [
                                                                                {
                                                                                        "type": "scheduleSlot",
                                                                                        "id": "1634914800000",
                                                                                        "start": 1768214415,
                                                                                        "end": 1768218015,
                                                                                        "title": "First slot",
                                                                                        "description": "First slot of the day",
                                                                                        "imageUrl": "https://robohash.org/1634914800000.png?size=35x35&set=set2"
                                                                                },
                                                                                {
                                                                                        "type": "scheduleSlot",
                                                                                        "id": "1634914800001",
                                                                                        "start": 1768218015,
                                                                                        "end": 1768221615,
                                                                                        "title": "second slot",
                                                                                        "description": "second slot of the day",
                                                                                        "imageUrl": "https://robohash.org/1634914800000.png?size=35x35&set=set3"
                                                                                },
                                                                                {
                                                                                        "type": "scheduleSlot",
                                                                                        "id": "1634914800002",
                                                                                        "start": 1768221615,
                                                                                        "end": 1768225215,
                                                                                        "title": "third slot",
                                                                                        "description": "third slot of the day",
                                                                                        "imageUrl": "https://robohash.org/1634914800000.png?size=35x35&set=set4"
                                                                                }
                                                                        ]
                                                                }
                                                        ]
                                                }
                                        }
                                ]
                        }
                }
        },
        {
                "type": "message",
                "text": "",
                "channelData": {
                        "metadata": [],
                        "structuredContent": {
                                "quickReplies": {
                                        "type": "quickReplies",
                                        "itemsPerRow": 8,
                                        "replies": [
                                                {
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "text": "Web Card",
                                                                                "type": "publishText"
                                                                        }
                                                                ]
                                                        },
                                                        "title": "Card",
                                                        "tooltip": "",
                                                        "type": "button"
                                                },
                                                {
                                                        "type": "button",
                                                        "title": "Web Carousel",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "text": "Web Carousel",
                                                                                "type": "publishText"
                                                                        }
                                                                ]
                                                        },
                                                        "tooltip": ""
                                                },
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Date Picker",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "text": "Web Date Picker",
                                                                                "type": "publishText"
                                                                        }
                                                                ]
                                                        }
                                                },
                                                {
                                                        "tooltip": "",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "Web Multiple Checklist"
                                                                        }
                                                                ]
                                                        },
                                                        "title": "Multiple Checklist",
                                                        "type": "button"
                                                },
                                                {
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "text": "Vendor Actions",
                                                                                "type": "publishText"
                                                                        }
                                                                ]
                                                        },
                                                        "tooltip": "",
                                                        "type": "button",
                                                        "title": "Vendor Actions"
                                                }
                                        ]
                                },
                                "message": "Which type of rich content do you want to see?"
                        }
                }
        }
]
}


export function welcome() {
    return [
        {
                "type": "message",
                "text": "Hello, I'm here to show how Rich Content and specific Vendor Actions are working with the Microsoft Bot Framework"
        },
        {
                "type": "message",
                "text": "If you don't see quick replies below the next message, you are probably coming from WhatsApp or Apple Business Chat. They don't support quick replies, so you have to type in the options: \"Rich Content text based\" or \"Vendor Actions text based\"."
        },
        {
                "type": "message",
                "text": "",
                "channelData": {
                        "metadata": [],
                        "structuredContent": {
                                "quickReplies": {
                                        "type": "quickReplies",
                                        "itemsPerRow": 8,
                                        "replies": [
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Rich Content",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "Rich Content"
                                                                        }
                                                                ],
                                                                "metadata": []
                                                        }
                                                },
                                                {
                                                        "type": "button",
                                                        "tooltip": "",
                                                        "title": "Vendor Actions",
                                                        "click": {
                                                                "actions": [
                                                                        {
                                                                                "type": "publishText",
                                                                                "text": "Vendor Actions"
                                                                        }
                                                                ],
                                                                "metadata": []
                                                        }
                                                }
                                        ]
                                },
                                "message": "What are you interested in?"
                        }
                }
        }
]
}


export function whatsAppReplyButton() {
    return [
        {
                "type": "message",
                "text": "WhatsApp offers at the moment only one type of Rich Content."
        },
        {
                "type": "message",
                "text": "In WhatsApp Business Messages, a Reply Button Message has the following structure: Header (optional), title, subtitle, footer (optional) and buttons (between 1 and 3)."
        },
        {
                "type": "message",
                "text": "",
                "channelData": {
                        "metadata": [],
                        "structuredContent": {
                                "type": "vertical",
                                "tag": "generic",
                                "elements": [
                                        {
                                                "type": "image",
                                                "url": "https://i.imgur.com/8meDl0W.jpeg"
                                        },
                                        {
                                                "type": "text",
                                                "text": "LivePerson",
                                                "tag": "title"
                                        },
                                        {
                                                "type": "text",
                                                "text": "The world's most innovative brands choose LivePerson's Conversational Cloud",
                                                "tag": "subtitle"
                                        },
                                        {
                                                "type": "text",
                                                "text": "The First AI-powered Conversational Cloud",
                                                "tag": "footer"
                                        },
                                        {
                                                "type": "button",
                                                "title": "WA Rich Content",
                                                "click": {
                                                        "actions": [
                                                                {
                                                                        "type": "publishText",
                                                                        "text": "WA Rich Content"
                                                                }
                                                        ]
                                                }
                                        },
                                        {
                                                "type": "button",
                                                "title": "WA Vendor Actions",
                                                "click": {
                                                        "actions": [
                                                                {
                                                                        "type": "publishText",
                                                                        "text": "WA Vendor Actions"
                                                                }
                                                        ]
                                                }
                                        }
                                ]
                        }
                }
        }
]
}


