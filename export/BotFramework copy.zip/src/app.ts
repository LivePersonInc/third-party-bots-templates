import {
  BotFrameworkAdapter,
  ConversationState,
  MemoryStorage
} from "botbuilder";
import { DialogSet } from "botbuilder-dialogs";
import * as restify from "restify";
import * as path from "path";
import { config } from "dotenv";
import { LpDialogBot } from "./bots/lpDialog";

// Ensuring we have all the config needed for application
const ENV_FILE = path.join(__dirname, ".env");
config({ path: ENV_FILE });

// Create adapter.
// See https://aka.ms/about-bot-adapter to learn more about adapters.
const server = restify.createServer();
server.listen(process.env.port || process.env.PORT || 3978, function() {
  console.log(`${server.name} listening to ${server.url}`);
});

const conversationState = new ConversationState(new MemoryStorage());

const dialogs = new DialogSet(conversationState.createProperty("dialogState"));

const adapter = new BotFrameworkAdapter({
  appId: process.env.ENV == "PROD" ? process.env.MICROSOFT_APP_ID : "",
  appPassword:
    process.env.ENV == "PROD" ? process.env.MICROSOFT_APP_PASSWORD : ""
});

// Catch-all for errors.
adapter.onTurnError = async (context, error) => {
  // This check writes out errors to console log
  console.error(`\n [onTurnError]: ${error}`);
  // Send a message to the user
  await context.sendActivity(`Oops. Something went wrong!`);
  // Clear out state
};

const lpDialog: LpDialogBot = new LpDialogBot(dialogs, conversationState);

server.post("/api/messages", (req, res) => {
  adapter.processActivity(req, res, async context => {
    await lpDialog.onTurn(context);
  });
});
