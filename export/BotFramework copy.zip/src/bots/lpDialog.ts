// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.
import { TurnContext, ConversationState } from 'botbuilder';
import { DialogSet } from 'botbuilder-dialogs';

import intents from './intents/intents.json';

export class LpDialogBot {
    private _dialogs: DialogSet;
    private _conversationState: ConversationState;
    private _userResponse: string;
    constructor(dialogs: DialogSet, conversationState: ConversationState) {
        this._dialogs = dialogs;
        this._conversationState = conversationState;
        this._userResponse = '';
    }

    async onTurn(context: TurnContext) {
        const dc = await this._dialogs.createContext(context);

        await dc.continueDialog(); // this allows continuation of the conversation and will get the last active dialog and continue conversation from there rather starting conversation from start

        if (context.activity.type === 'message' && context.activity.text !== null) {
            console.log('Message is received so will send response accordingly');
            this._userResponse = context.activity.text.toLowerCase();

            const matchedIntent = this.matchIntent();
            const richContent = await import('./richContent');
            const payload = richContent[matchedIntent]();
            await context.sendActivities(payload);
        } else {
            console.log(`${context.activity.type} event detected`);
        }
        await this._conversationState.saveChanges(context); // it will always save the context in the conversation after responding. This helps in identifying what was the previous state of dialog
    }

    private matchIntent() {
        let matchedIntent: string;
        Object.keys(intents).forEach((key) => {
            const currentIntent = intents[key];
            if (currentIntent.some((e: string) => e === this._userResponse)) {
                matchedIntent = key;
            }
        });
        return matchedIntent;
    }
}
