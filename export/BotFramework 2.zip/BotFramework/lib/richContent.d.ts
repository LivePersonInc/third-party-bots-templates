export declare function agentTransfer(): ({
    type: string;
    text: string;
    channelData?: undefined;
} | {
    type: string;
    text: string;
    channelData: {
        action: {
            name: string;
            parameters: {
                skill: string;
                agentId: string;
            };
        };
    };
})[];
export declare function apple(): {
    type: string;
    text: string;
}[];
export declare function appleAuth(): ({
    type: string;
    text: string;
    channelData?: undefined;
} | {
    type: string;
    text: string;
    channelData: {
        metadata: ({
            type: string;
            receivedMessage: {
                title: string;
                subtitle: string;
                imageURL: string;
                style: string;
            };
            replyMessage: {
                title: string;
                subtitle: string;
                imageURL: string;
                style: string;
            };
            requestIdentifier?: undefined;
            apple?: undefined;
        } | {
            type: string;
            requestIdentifier: string;
            apple: {
                oauth2: {
                    responseEncryptionKey: string;
                };
            };
            receivedMessage?: undefined;
            replyMessage?: undefined;
        })[];
        structuredContent: {
            tag: string;
            type: string;
            elements: ({
                type: string;
                url: string;
                text?: undefined;
            } | {
                type: string;
                text: string;
                url?: undefined;
            })[];
        };
    };
})[];
export declare function appleCustomInteractiveMessage(): ({
    type: string;
    text: string;
    channelData?: undefined;
} | {
    type: string;
    text: string;
    channelData: {
        metadata: any[];
        structuredContent: {
            type: string;
            tag: string;
            elements: ({
                type: string;
                url: string;
                title?: undefined;
                click?: undefined;
            } | {
                type: string;
                title: string;
                click: {
                    actions: {
                        type: string;
                        uri: string;
                    }[];
                };
                url?: undefined;
            })[];
        };
    };
})[];
export declare function appleListPicker(): ({
    type: string;
    text: string;
    channelData?: undefined;
} | {
    type: string;
    text: string;
    channelData: {
        metadata: {
            replyMessage: {
                secondarySubtitle: string;
                imageURL: string;
                tertiarySubtitle: string;
                subtitle: string;
                title: string;
                style: string;
            };
            multipleSelection: boolean[];
            type: string;
            receivedMessage: {
                tertiarySubtitle: string;
                imageURL: string;
                subtitle: string;
                secondarySubtitle: string;
                style: string;
                title: string;
            };
        }[];
        structuredContent: {
            elements: {
                elements: ({
                    text: string;
                    tooltip: string;
                    type: string;
                    style: {
                        size: string;
                        bold: boolean;
                    };
                    elements?: undefined;
                } | {
                    type: string;
                    elements: ({
                        type: string;
                        url: string;
                        tooltip: string;
                        elements?: undefined;
                    } | {
                        type: string;
                        elements: ({
                            type: string;
                            tag: string;
                            tooltip: string;
                            text: string;
                            style: {
                                size: string;
                                bold: boolean;
                            };
                            title?: undefined;
                            click?: undefined;
                        } | {
                            tag: string;
                            tooltip: string;
                            text: string;
                            type: string;
                            style?: undefined;
                            title?: undefined;
                            click?: undefined;
                        } | {
                            title: string;
                            click: {
                                metadata: any[];
                                actions: {
                                    text: string;
                                    type: string;
                                }[];
                            };
                            type: string;
                            tooltip: string;
                            tag?: undefined;
                            text?: undefined;
                            style?: undefined;
                        })[];
                        url?: undefined;
                        tooltip?: undefined;
                    })[];
                    text?: undefined;
                    tooltip?: undefined;
                    style?: undefined;
                } | {
                    type: string;
                    elements: ({
                        url: string;
                        tooltip: string;
                        type: string;
                        elements?: undefined;
                    } | {
                        elements: ({
                            tag: string;
                            tooltip: string;
                            style: {
                                size: string;
                                bold: boolean;
                            };
                            type: string;
                            text: string;
                            title?: undefined;
                            click?: undefined;
                        } | {
                            tag: string;
                            tooltip: string;
                            text: string;
                            type: string;
                            style?: undefined;
                            title?: undefined;
                            click?: undefined;
                        } | {
                            tooltip: string;
                            title: string;
                            type: string;
                            click: {
                                actions: {
                                    type: string;
                                    text: string;
                                }[];
                            };
                            tag?: undefined;
                            style?: undefined;
                            text?: undefined;
                        })[];
                        type: string;
                        url?: undefined;
                        tooltip?: undefined;
                    })[];
                    text?: undefined;
                    tooltip?: undefined;
                    style?: undefined;
                })[];
                type: string;
            }[];
            type: string;
            tag: string;
        };
    };
})[];
export declare function applePay(): ({
    type: string;
    text: string;
    channelData?: undefined;
} | {
    type: string;
    text: string;
    channelData: {
        metadata: any[];
        structuredContent: {
            type: string;
            tag: string;
            elements: ({
                type: string;
                url: string;
                title?: undefined;
                click?: undefined;
            } | {
                type: string;
                title: string;
                click: {
                    actions: {
                        type: string;
                        uri: string;
                    }[];
                };
                url?: undefined;
            })[];
        };
    };
})[];
export declare function appleRichLinks(): ({
    type: string;
    text: string;
    channelData?: undefined;
} | {
    type: string;
    text: string;
    channelData: {
        metadata: any[];
        structuredContent: {
            type: string;
            tag: string;
            elements: ({
                type: string;
                url: string;
                title?: undefined;
                click?: undefined;
            } | {
                type: string;
                title: string;
                click: {
                    actions: {
                        type: string;
                        uri: string;
                    }[];
                };
                url?: undefined;
            })[];
        };
    };
})[];
export declare function appleTimePicker(): ({
    type: string;
    text: string;
    channelData?: undefined;
} | {
    type: string;
    text: string;
    channelData: {
        metadata: ({
            location: {
                la: number;
                radius: number;
                lo: number;
                title: string;
            };
            type: string;
            title: string;
            timing: {
                presentedTimezoneOffset: number;
            };
            replyMessage?: undefined;
            receivedMessage?: undefined;
        } | {
            replyMessage: {
                subtitle: string;
                style: string;
                title: string;
                imageURL: string;
            };
            type: string;
            receivedMessage: {
                imageURL: string;
                style: string;
                title: string;
                subtitle: string;
            };
            location?: undefined;
            title?: undefined;
            timing?: undefined;
        })[];
        structuredContent: {
            elements: ({
                text: string;
                style: {
                    bold: boolean;
                    size: string;
                };
                type: string;
                tag: string;
                elements?: undefined;
            } | {
                text: string;
                type: string;
                style?: undefined;
                tag?: undefined;
                elements?: undefined;
            } | {
                type: string;
                elements: {
                    title: string;
                    click: {
                        metadata: ({
                            type: string;
                            id: string;
                            timing?: undefined;
                        } | {
                            timing: {
                                duration: number;
                                startTime: string;
                            };
                            type: string;
                            id?: undefined;
                        })[];
                        actions: {
                            type: string;
                            text: string;
                        }[];
                    };
                    type: string;
                }[];
                text?: undefined;
                style?: undefined;
                tag?: undefined;
            })[];
            tag: string;
            type: string;
        };
    };
})[];
export declare function endConversation(): ({
    type: string;
    text: string;
    channelData?: undefined;
} | {
    type: string;
    text: string;
    channelData: {
        action: {
            name: string;
        };
    };
})[];
export declare function delayPauseConversation(): ({
    type: string;
    text: string;
    channelData?: undefined;
} | {
    type: string;
    text: string;
    channelData: {
        delay: {
            delay: number;
            typing: boolean;
        };
        metadata?: undefined;
        structuredContent?: undefined;
    };
} | {
    type: string;
    text: string;
    channelData: {
        metadata: any[];
        structuredContent: {
            quickReplies: {
                type: string;
                itemsPerRow: number;
                replies: {
                    type: string;
                    tooltip: string;
                    title: string;
                    click: {
                        actions: {
                            type: string;
                            text: string;
                        }[];
                        metadata: any[];
                    };
                }[];
            };
            message: string;
        };
        delay?: undefined;
    };
})[];
export declare function encodedMetadata(): ({
    type: string;
    text: string;
    channelData?: undefined;
} | {
    type: string;
    text: string;
    channelData: {
        encodedMetadata: string;
        metadata?: undefined;
        structuredContent?: undefined;
    };
} | {
    type: string;
    text: string;
    channelData: {
        metadata: any[];
        structuredContent: {
            quickReplies: {
                type: string;
                itemsPerRow: number;
                replies: {
                    type: string;
                    tooltip: string;
                    title: string;
                    click: {
                        actions: {
                            type: string;
                            text: string;
                        }[];
                        metadata: any[];
                    };
                }[];
            };
            message: string;
        };
        encodedMetadata?: undefined;
    };
})[];
export declare function facebook(): {
    type: string;
    text: string;
    channelData: {
        metadata: any[];
        structuredContent: {
            quickReplies: {
                type: string;
                itemsPerRow: number;
                replies: {
                    type: string;
                    tooltip: string;
                    title: string;
                    click: {
                        actions: {
                            type: string;
                            text: string;
                        }[];
                        metadata: any[];
                    };
                }[];
            };
            message: string;
        };
    };
}[];
export declare function facebookButton(): ({
    type: string;
    text: string;
    channelData?: undefined;
} | {
    type: string;
    text: string;
    channelData: {
        metadata: any[];
        structuredContent: {
            type: string;
            tag: string;
            elements: {
                type: string;
                elements: ({
                    type: string;
                    tag: string;
                    text: string;
                    tooltip: string;
                    title?: undefined;
                    click?: undefined;
                } | {
                    type: string;
                    tooltip: string;
                    title: string;
                    click: {
                        actions: {
                            type: string;
                            name: string;
                            uri: string;
                        }[];
                    };
                    tag?: undefined;
                    text?: undefined;
                } | {
                    type: string;
                    title: string;
                    click: {
                        actions: {
                            type: string;
                            lo: number;
                            la: number;
                        }[];
                    };
                    tag?: undefined;
                    text?: undefined;
                    tooltip?: undefined;
                } | {
                    type: string;
                    tooltip: string;
                    title: string;
                    click: {
                        actions: {
                            type: string;
                            text: string;
                        }[];
                    };
                    tag?: undefined;
                    text?: undefined;
                })[];
            }[];
            quickReplies?: undefined;
            message?: undefined;
        };
    };
} | {
    type: string;
    text: string;
    channelData: {
        metadata: any[];
        structuredContent: {
            quickReplies: {
                type: string;
                itemsPerRow: number;
                replies: {
                    type: string;
                    tooltip: string;
                    title: string;
                    click: {
                        actions: {
                            type: string;
                            text: string;
                        }[];
                        metadata: any[];
                    };
                }[];
            };
            message: string;
            type?: undefined;
            tag?: undefined;
            elements?: undefined;
        };
    };
})[];
export declare function facebookCarousel(): ({
    type: string;
    text: string;
    channelData?: undefined;
} | {
    type: string;
    text: string;
    channelData: {
        metadata: any[];
        structuredContent: {
            type: string;
            elements: {
                type: string;
                tag: string;
                elements: {
                    type: string;
                    elements: ({
                        type: string;
                        tooltip: string;
                        url: string;
                        tag?: undefined;
                        text?: undefined;
                        title?: undefined;
                        click?: undefined;
                    } | {
                        type: string;
                        tag: string;
                        text: string;
                        tooltip: string;
                        url?: undefined;
                        title?: undefined;
                        click?: undefined;
                    } | {
                        type: string;
                        title: string;
                        click: {
                            actions: {
                                type: string;
                                uri: string;
                            }[];
                        };
                        tooltip: string;
                        url?: undefined;
                        tag?: undefined;
                        text?: undefined;
                    })[];
                }[];
            }[];
            quickReplies?: undefined;
            message?: undefined;
        };
    };
} | {
    type: string;
    text: string;
    channelData: {
        metadata: any[];
        structuredContent: {
            quickReplies: {
                type: string;
                itemsPerRow: number;
                replies: {
                    type: string;
                    tooltip: string;
                    title: string;
                    click: {
                        actions: {
                            type: string;
                            text: string;
                        }[];
                        metadata: any[];
                    };
                }[];
            };
            message: string;
            type?: undefined;
            elements?: undefined;
        };
    };
})[];
export declare function facebookGeneric(): ({
    type: string;
    text: string;
    channelData?: undefined;
} | {
    type: string;
    text: string;
    channelData: {
        metadata: any[];
        structuredContent: {
            type: string;
            tag: string;
            elements: {
                type: string;
                elements: ({
                    type: string;
                    url: string;
                    tooltip: string;
                    tag?: undefined;
                    text?: undefined;
                    title?: undefined;
                    click?: undefined;
                } | {
                    type: string;
                    tag: string;
                    text: string;
                    tooltip: string;
                    url?: undefined;
                    title?: undefined;
                    click?: undefined;
                } | {
                    type: string;
                    tooltip: string;
                    title: string;
                    click: {
                        actions: {
                            type: string;
                            text: string;
                        }[];
                    };
                    url?: undefined;
                    tag?: undefined;
                    text?: undefined;
                } | {
                    type: string;
                    tooltip: string;
                    title: string;
                    click: {
                        actions: {
                            type: string;
                            name: string;
                            uri: string;
                        }[];
                    };
                    url?: undefined;
                    tag?: undefined;
                    text?: undefined;
                } | {
                    type: string;
                    title: string;
                    click: {
                        actions: {
                            type: string;
                            lo: number;
                            la: number;
                        }[];
                    };
                    url?: undefined;
                    tooltip?: undefined;
                    tag?: undefined;
                    text?: undefined;
                })[];
            }[];
            quickReplies?: undefined;
            message?: undefined;
        };
    };
} | {
    type: string;
    text: string;
    channelData: {
        metadata: any[];
        structuredContent: {
            quickReplies: {
                type: string;
                itemsPerRow: number;
                replies: {
                    type: string;
                    tooltip: string;
                    title: string;
                    click: {
                        actions: {
                            type: string;
                            text: string;
                        }[];
                        metadata: any[];
                    };
                }[];
            };
            message: string;
            type?: undefined;
            tag?: undefined;
            elements?: undefined;
        };
    };
})[];
export declare function facebookQuickReplies(): ({
    type: string;
    text: string;
    channelData?: undefined;
} | {
    type: string;
    text: string;
    channelData: {
        metadata: any[];
        structuredContent: {
            quickReplies: {
                type: string;
                itemsPerRow: number;
                replies: {
                    type: string;
                    tooltip: string;
                    title: string;
                    click: {
                        actions: {
                            type: string;
                            text: string;
                        }[];
                        metadata: any[];
                    };
                }[];
            };
            message: string;
        };
    };
})[];
export declare function gbm(): {
    type: string;
    text: string;
    channelData: {
        metadata: any[];
        structuredContent: {
            quickReplies: {
                type: string;
                itemsPerRow: number;
                replies: {
                    type: string;
                    tooltip: string;
                    title: string;
                    click: {
                        actions: {
                            type: string;
                            text: string;
                        }[];
                    };
                }[];
            };
            message: string;
        };
    };
}[];
export declare function gbmCard(): ({
    type: string;
    text: string;
    channelData?: undefined;
} | {
    type: string;
    text: string;
    channelData: {
        metadata: any[];
        structuredContent: {
            type: string;
            tag: string;
            display: {
                size: string;
            };
            elements: ({
                type: string;
                url: string;
                tag?: undefined;
                text?: undefined;
                title?: undefined;
                click?: undefined;
            } | {
                type: string;
                tag: string;
                text: string;
                url?: undefined;
                title?: undefined;
                click?: undefined;
            } | {
                type: string;
                text: string;
                url?: undefined;
                tag?: undefined;
                title?: undefined;
                click?: undefined;
            } | {
                type: string;
                title: string;
                click: {
                    actions: {
                        type: string;
                        uri: string;
                    }[];
                };
                url?: undefined;
                tag?: undefined;
                text?: undefined;
            } | {
                type: string;
                title: string;
                click: {
                    actions: {
                        type: string;
                        lo: number;
                        la: number;
                    }[];
                };
                url?: undefined;
                tag?: undefined;
                text?: undefined;
            } | {
                type: string;
                title: string;
                click: {
                    actions: {
                        type: string;
                        text: string;
                    }[];
                };
                url?: undefined;
                tag?: undefined;
                text?: undefined;
            })[];
            quickReplies?: undefined;
            message?: undefined;
        };
        delay?: undefined;
    };
} | {
    type: string;
    text: string;
    channelData: {
        delay: {
            delay: number;
            typing: boolean;
        };
        metadata?: undefined;
        structuredContent?: undefined;
    };
} | {
    type: string;
    text: string;
    channelData: {
        metadata: any[];
        structuredContent: {
            quickReplies: {
                type: string;
                itemsPerRow: number;
                replies: {
                    type: string;
                    tooltip: string;
                    title: string;
                    click: {
                        actions: {
                            type: string;
                            text: string;
                        }[];
                    };
                }[];
            };
            message: string;
            type?: undefined;
            tag?: undefined;
            display?: undefined;
            elements?: undefined;
        };
        delay?: undefined;
    };
})[];
export declare function gbmCarousel(): ({
    type: string;
    text: string;
    channelData?: undefined;
} | {
    type: string;
    text: string;
    channelData: {
        metadata: any[];
        structuredContent: {
            type: string;
            elements: {
                type: string;
                tag: string;
                display: {
                    size: string;
                };
                elements: ({
                    type: string;
                    url: string;
                    tag?: undefined;
                    text?: undefined;
                    title?: undefined;
                    click?: undefined;
                } | {
                    type: string;
                    tag: string;
                    text: string;
                    url?: undefined;
                    title?: undefined;
                    click?: undefined;
                } | {
                    type: string;
                    text: string;
                    url?: undefined;
                    tag?: undefined;
                    title?: undefined;
                    click?: undefined;
                } | {
                    type: string;
                    title: string;
                    click: {
                        actions: {
                            type: string;
                            uri: string;
                        }[];
                    };
                    url?: undefined;
                    tag?: undefined;
                    text?: undefined;
                })[];
            }[];
            quickReplies?: undefined;
            message?: undefined;
        };
        delay?: undefined;
    };
} | {
    type: string;
    text: string;
    channelData: {
        delay: {
            delay: number;
            typing: boolean;
        };
        metadata?: undefined;
        structuredContent?: undefined;
    };
} | {
    type: string;
    text: string;
    channelData: {
        metadata: any[];
        structuredContent: {
            quickReplies: {
                type: string;
                itemsPerRow: number;
                replies: {
                    type: string;
                    tooltip: string;
                    title: string;
                    click: {
                        actions: {
                            type: string;
                            text: string;
                        }[];
                    };
                }[];
            };
            message: string;
            type?: undefined;
            elements?: undefined;
        };
        delay?: undefined;
    };
})[];
export declare function gbmQuickReplies(): ({
    type: string;
    text: string;
    channelData?: undefined;
} | {
    type: string;
    text: string;
    channelData: {
        metadata: any[];
        structuredContent: {
            quickReplies: {
                type: string;
                itemsPerRow: number;
                replies: {
                    type: string;
                    tooltip: string;
                    title: string;
                    click: {
                        actions: {
                            type: string;
                            text: string;
                        }[];
                    };
                }[];
            };
            message: string;
        };
    };
})[];
export declare function invokeFunction(): ({
    type: string;
    text: string;
    channelData?: undefined;
} | {
    type: string;
    channelData: {
        messageAudience: string;
        metadata?: undefined;
        structuredContent?: undefined;
    };
    text?: undefined;
} | {
    type: string;
    text: string;
    channelData: {
        metadata: any[];
        structuredContent: {
            quickReplies: {
                type: string;
                itemsPerRow: number;
                replies: {
                    type: string;
                    tooltip: string;
                    title: string;
                    click: {
                        actions: {
                            type: string;
                            text: string;
                        }[];
                        metadata: any[];
                    };
                }[];
            };
            message: string;
        };
        messageAudience?: undefined;
    };
})[];
export declare function line(): {
    type: string;
    text: string;
    channelData: {
        metadata: any[];
        structuredContent: {
            quickReplies: {
                type: string;
                itemsPerRow: number;
                replies: {
                    type: string;
                    tooltip: string;
                    title: string;
                    click: {
                        actions: {
                            type: string;
                            text: string;
                        }[];
                        metadata: any[];
                    };
                }[];
            };
            message: string;
        };
    };
}[];
export declare function lineCard(): ({
    type: string;
    text: string;
    channelData?: undefined;
} | {
    type: string;
    text: string;
    channelData: {
        metadata: any[];
        structuredContent: {
            type: string;
            tag: string;
            alt: string;
            elements: {
                type: string;
                elements: ({
                    type: string;
                    url: string;
                    tooltip: string;
                    tag?: undefined;
                    text?: undefined;
                    title?: undefined;
                    click?: undefined;
                } | {
                    type: string;
                    tag: string;
                    text: string;
                    tooltip: string;
                    url?: undefined;
                    title?: undefined;
                    click?: undefined;
                } | {
                    type: string;
                    tooltip: string;
                    title: string;
                    click: {
                        actions: {
                            type: string;
                            text: string;
                        }[];
                    };
                    url?: undefined;
                    tag?: undefined;
                    text?: undefined;
                } | {
                    type: string;
                    tooltip: string;
                    title: string;
                    click: {
                        actions: {
                            type: string;
                            name: string;
                            uri: string;
                        }[];
                    };
                    url?: undefined;
                    tag?: undefined;
                    text?: undefined;
                })[];
            }[];
            quickReplies?: undefined;
            message?: undefined;
        };
    };
} | {
    type: string;
    text: string;
    channelData: {
        metadata: any[];
        structuredContent: {
            quickReplies: {
                type: string;
                itemsPerRow: number;
                replies: {
                    type: string;
                    tooltip: string;
                    title: string;
                    click: {
                        actions: {
                            type: string;
                            text: string;
                        }[];
                        metadata: any[];
                    };
                }[];
            };
            message: string;
            type?: undefined;
            tag?: undefined;
            alt?: undefined;
            elements?: undefined;
        };
    };
})[];
export declare function lineCarousel(): ({
    type: string;
    text: string;
    channelData?: undefined;
} | {
    type: string;
    text: string;
    channelData: {
        metadata: any[];
        structuredContent: {
            type: string;
            padding: number;
            alt: string;
            elements: {
                type: string;
                tag: string;
                elements: {
                    type: string;
                    elements: ({
                        type: string;
                        url: string;
                        tooltip: string;
                        tag?: undefined;
                        text?: undefined;
                        title?: undefined;
                        click?: undefined;
                    } | {
                        type: string;
                        tag: string;
                        text: string;
                        url?: undefined;
                        tooltip?: undefined;
                        title?: undefined;
                        click?: undefined;
                    } | {
                        type: string;
                        tag: string;
                        text: string;
                        tooltip: string;
                        url?: undefined;
                        title?: undefined;
                        click?: undefined;
                    } | {
                        type: string;
                        title: string;
                        click: {
                            actions: {
                                name: string;
                                type: string;
                                uri: string;
                            }[];
                        };
                        url?: undefined;
                        tooltip?: undefined;
                        tag?: undefined;
                        text?: undefined;
                    })[];
                }[];
            }[];
            quickReplies?: undefined;
            message?: undefined;
        };
    };
} | {
    type: string;
    text: string;
    channelData: {
        metadata: any[];
        structuredContent: {
            quickReplies: {
                type: string;
                itemsPerRow: number;
                replies: {
                    type: string;
                    tooltip: string;
                    title: string;
                    click: {
                        actions: {
                            type: string;
                            text: string;
                        }[];
                        metadata: any[];
                    };
                }[];
            };
            message: string;
            type?: undefined;
            padding?: undefined;
            alt?: undefined;
            elements?: undefined;
        };
    };
})[];
export declare function lineQR(): ({
    type: string;
    text: string;
    channelData?: undefined;
} | {
    type: string;
    text: string;
    channelData: {
        metadata: any[];
        structuredContent: {
            quickReplies: {
                type: string;
                itemsPerRow: number;
                replies: {
                    type: string;
                    tooltip: string;
                    title: string;
                    click: {
                        actions: {
                            type: string;
                            text: string;
                        }[];
                        metadata: any[];
                    };
                }[];
            };
            message: string;
        };
    };
})[];
export declare function privateMessage(): ({
    type: string;
    text: string;
    channelData?: undefined;
} | {
    type: string;
    text: string;
    channelData: {
        messageAudience: string;
        metadata?: undefined;
        structuredContent?: undefined;
    };
} | {
    type: string;
    text: string;
    channelData: {
        metadata: any[];
        structuredContent: {
            quickReplies: {
                type: string;
                itemsPerRow: number;
                replies: {
                    type: string;
                    tooltip: string;
                    title: string;
                    click: {
                        actions: {
                            type: string;
                            text: string;
                        }[];
                        metadata: any[];
                    };
                }[];
            };
            message: string;
        };
        messageAudience?: undefined;
    };
})[];
export declare function rcs(): {
    type: string;
    text: string;
    channelData: {
        metadata: any[];
        structuredContent: {
            quickReplies: {
                type: string;
                itemsPerRow: number;
                replies: {
                    type: string;
                    tooltip: string;
                    title: string;
                    click: {
                        actions: {
                            type: string;
                            text: string;
                        }[];
                        metadata: any[];
                    };
                }[];
            };
            message: string;
        };
    };
}[];
export declare function rcsCard(): ({
    type: string;
    text: string;
    channelData?: undefined;
} | {
    type: string;
    text: string;
    channelData: {
        metadata: any[];
        structuredContent: {
            type: string;
            tag: string;
            elements: {
                type: string;
                elements: ({
                    type: string;
                    url: string;
                    tag?: undefined;
                    text?: undefined;
                    title?: undefined;
                    click?: undefined;
                } | {
                    type: string;
                    tag: string;
                    text: string;
                    url?: undefined;
                    title?: undefined;
                    click?: undefined;
                } | {
                    type: string;
                    title: string;
                    click: {
                        actions: {
                            type: string;
                            uri: string;
                        }[];
                    };
                    url?: undefined;
                    tag?: undefined;
                    text?: undefined;
                } | {
                    type: string;
                    title: string;
                    click: {
                        actions: {
                            type: string;
                            lo: number;
                            la: number;
                        }[];
                    };
                    url?: undefined;
                    tag?: undefined;
                    text?: undefined;
                } | {
                    type: string;
                    title: string;
                    click: {
                        actions: {
                            type: string;
                            text: string;
                        }[];
                    };
                    url?: undefined;
                    tag?: undefined;
                    text?: undefined;
                })[];
            }[];
            quickReplies?: undefined;
            message?: undefined;
        };
    };
} | {
    type: string;
    text: string;
    channelData: {
        metadata: any[];
        structuredContent: {
            quickReplies: {
                type: string;
                itemsPerRow: number;
                replies: {
                    type: string;
                    tooltip: string;
                    title: string;
                    click: {
                        actions: {
                            type: string;
                            text: string;
                        }[];
                        metadata: any[];
                    };
                }[];
            };
            message: string;
            type?: undefined;
            tag?: undefined;
            elements?: undefined;
        };
    };
})[];
export declare function rcsCarousel(): ({
    type: string;
    text: string;
    channelData?: undefined;
} | {
    type: string;
    text: string;
    channelData: {
        metadata: any[];
        structuredContent: {
            type: string;
            padding: number;
            elements: {
                type: string;
                tag: string;
                elements: {
                    type: string;
                    elements: ({
                        type: string;
                        url: string;
                        tooltip: string;
                        tag?: undefined;
                        text?: undefined;
                        title?: undefined;
                        click?: undefined;
                    } | {
                        type: string;
                        tag: string;
                        text: string;
                        url?: undefined;
                        tooltip?: undefined;
                        title?: undefined;
                        click?: undefined;
                    } | {
                        type: string;
                        tag: string;
                        text: string;
                        tooltip: string;
                        url?: undefined;
                        title?: undefined;
                        click?: undefined;
                    } | {
                        type: string;
                        title: string;
                        click: {
                            actions: {
                                name: string;
                                type: string;
                                uri: string;
                            }[];
                        };
                        url?: undefined;
                        tooltip?: undefined;
                        tag?: undefined;
                        text?: undefined;
                    })[];
                }[];
            }[];
            quickReplies?: undefined;
            message?: undefined;
        };
    };
} | {
    type: string;
    text: string;
    channelData: {
        metadata: any[];
        structuredContent: {
            quickReplies: {
                type: string;
                itemsPerRow: number;
                replies: {
                    type: string;
                    tooltip: string;
                    title: string;
                    click: {
                        actions: {
                            type: string;
                            text: string;
                        }[];
                        metadata: any[];
                    };
                }[];
            };
            message: string;
            type?: undefined;
            padding?: undefined;
            elements?: undefined;
        };
    };
})[];
export declare function rcsQuickReplies(): ({
    type: string;
    text: string;
    channelData?: undefined;
} | {
    type: string;
    text: string;
    channelData: {
        metadata: any[];
        structuredContent: {
            quickReplies: {
                type: string;
                itemsPerRow: number;
                replies: {
                    type: string;
                    tooltip: string;
                    title: string;
                    click: {
                        actions: {
                            type: string;
                            text: string;
                        }[];
                        metadata: any[];
                    };
                }[];
            };
            message: string;
        };
    };
})[];
export declare function richContentSelection(): {
    type: string;
    text: string;
    channelData: {
        metadata: any[];
        structuredContent: {
            quickReplies: {
                type: string;
                itemsPerRow: number;
                replies: {
                    type: string;
                    tooltip: string;
                    title: string;
                    click: {
                        actions: {
                            type: string;
                            text: string;
                        }[];
                    };
                }[];
            };
            message: string;
        };
    };
}[];
export declare function richContentSelectionTextBased(): {
    type: string;
    text: string;
}[];
export declare function skillTransfer(): ({
    type: string;
    text: string;
    channelData?: undefined;
} | {
    type: string;
    text: string;
    channelData: {
        action: {
            name: string;
            parameters: {
                skill: string;
            };
        };
    };
})[];
export declare function vendorActionSelection(): {
    type: string;
    text: string;
    channelData: {
        metadata: any[];
        structuredContent: {
            quickReplies: {
                type: string;
                itemsPerRow: number;
                replies: {
                    type: string;
                    tooltip: string;
                    title: string;
                    click: {
                        actions: {
                            type: string;
                            text: string;
                        }[];
                        metadata: any[];
                    };
                }[];
            };
            message: string;
        };
    };
}[];
export declare function vendorActionSelectionMore(): {
    type: string;
    text: string;
    channelData: {
        metadata: any[];
        structuredContent: {
            quickReplies: {
                type: string;
                itemsPerRow: number;
                replies: {
                    type: string;
                    tooltip: string;
                    title: string;
                    click: {
                        actions: {
                            type: string;
                            text: string;
                        }[];
                        metadata: any[];
                    };
                }[];
            };
            message: string;
        };
    };
}[];
export declare function vendorActionSelectionTextBased(): {
    type: string;
    text: string;
}[];
export declare function web(): {
    type: string;
    text: string;
    channelData: {
        metadata: any[];
        structuredContent: {
            quickReplies: {
                type: string;
                itemsPerRow: number;
                replies: {
                    type: string;
                    tooltip: string;
                    title: string;
                    click: {
                        actions: {
                            type: string;
                            text: string;
                        }[];
                    };
                }[];
            };
            message: string;
        };
    };
}[];
export declare function webCard(): ({
    type: string;
    text: string;
    channelData?: undefined;
} | {
    type: string;
    text: string;
    channelData: {
        metadata: any[];
        structuredContent: {
            type: string;
            elements: ({
                type: string;
                url: string;
                tooltip: string;
                text?: undefined;
                title?: undefined;
                click?: undefined;
            } | {
                type: string;
                text: string;
                tooltip: string;
                url?: undefined;
                title?: undefined;
                click?: undefined;
            } | {
                type: string;
                tooltip: string;
                title: string;
                click: {
                    actions: {
                        type: string;
                        name: string;
                        uri: string;
                    }[];
                };
                url?: undefined;
                text?: undefined;
            } | {
                type: string;
                title: string;
                click: {
                    actions: {
                        type: string;
                        lo: number;
                        la: number;
                    }[];
                };
                url?: undefined;
                tooltip?: undefined;
                text?: undefined;
            })[];
            quickReplies?: undefined;
            message?: undefined;
        };
    };
} | {
    type: string;
    text: string;
    channelData: {
        metadata: any[];
        structuredContent: {
            quickReplies: {
                type: string;
                itemsPerRow: number;
                replies: {
                    type: string;
                    tooltip: string;
                    title: string;
                    click: {
                        actions: {
                            type: string;
                            text: string;
                        }[];
                    };
                }[];
            };
            message: string;
            type?: undefined;
            elements?: undefined;
        };
    };
})[];
export declare function webCarousel(): ({
    type: string;
    text: string;
    channelData?: undefined;
} | {
    type: string;
    text: string;
    channelData: {
        metadata: any[];
        structuredContent: {
            type: string;
            padding: number;
            elements: {
                type: string;
                elements: ({
                    type: string;
                    url: string;
                    tooltip: string;
                    text?: undefined;
                    title?: undefined;
                    click?: undefined;
                } | {
                    type: string;
                    text: string;
                    tooltip: string;
                    url?: undefined;
                    title?: undefined;
                    click?: undefined;
                } | {
                    type: string;
                    tooltip: string;
                    title: string;
                    click: {
                        actions: {
                            type: string;
                            name: string;
                            uri: string;
                        }[];
                    };
                    url?: undefined;
                    text?: undefined;
                })[];
            }[];
            quickReplies?: undefined;
            message?: undefined;
        };
    };
} | {
    type: string;
    text: string;
    channelData: {
        metadata: any[];
        structuredContent: {
            quickReplies: {
                type: string;
                itemsPerRow: number;
                replies: {
                    type: string;
                    tooltip: string;
                    title: string;
                    click: {
                        actions: {
                            type: string;
                            text: string;
                        }[];
                    };
                }[];
            };
            message: string;
            type?: undefined;
            padding?: undefined;
            elements?: undefined;
        };
    };
})[];
export declare function webDatePicker(): ({
    type: string;
    text: string;
    channelData?: undefined;
} | {
    type: string;
    text: string;
    channelData: {
        metadata: any[];
        structuredContent: {
            type: string;
            border: string;
            elements: ({
                type: string;
                borderLine: boolean;
                percentages: number[];
                elements: ({
                    type: string;
                    url: string;
                    tooltip: string;
                    elements?: undefined;
                } | {
                    type: string;
                    elements: ({
                        type: string;
                        text: string;
                        tooltip: string;
                        style: {
                            bold: boolean;
                            size: string;
                        };
                    } | {
                        type: string;
                        text: string;
                        tooltip: string;
                        style?: undefined;
                    })[];
                    url?: undefined;
                    tooltip?: undefined;
                })[];
                tooltip?: undefined;
                title?: undefined;
                class?: undefined;
                style?: undefined;
                click?: undefined;
            } | {
                type: string;
                tooltip: string;
                title: string;
                class: string;
                style: {
                    "background-color": string;
                    color: string;
                    size: string;
                    bold: boolean;
                };
                click: {
                    actions: {
                        type: string;
                        class: string;
                        title: string;
                        minDate: number;
                        maxDate: number;
                        dateFormat: string;
                    }[];
                };
                borderLine?: undefined;
                percentages?: undefined;
                elements?: undefined;
            })[];
            quickReplies?: undefined;
            message?: undefined;
        };
    };
} | {
    type: string;
    text: string;
    channelData: {
        metadata: any[];
        structuredContent: {
            quickReplies: {
                type: string;
                itemsPerRow: number;
                replies: {
                    type: string;
                    tooltip: string;
                    title: string;
                    click: {
                        actions: {
                            type: string;
                            text: string;
                        }[];
                    };
                }[];
            };
            message: string;
            type?: undefined;
            border?: undefined;
            elements?: undefined;
        };
    };
})[];
export declare function webFallback(): {
    type: string;
    text: string;
    channelData: {
        metadata: any[];
        structuredContent: {
            quickReplies: {
                type: string;
                itemsPerRow: number;
                replies: {
                    type: string;
                    tooltip: string;
                    title: string;
                    click: {
                        actions: {
                            type: string;
                            text: string;
                        }[];
                    };
                }[];
            };
            message: string;
        };
    };
}[];
export declare function webMultipleChecklist(): ({
    type: string;
    text: string;
    channelData?: undefined;
} | {
    type: string;
    text: string;
    channelData: {
        metadata: any[];
        structuredContent: {
            type: string;
            elements: ({
                type: string;
                text: string;
                elements?: undefined;
            } | {
                type: string;
                elements: {
                    type: string;
                    sectionID: string;
                    elements: ({
                        type: string;
                        text: string;
                        elements?: undefined;
                    } | {
                        type: string;
                        elements: {
                            type: string;
                            text: string;
                            borderLine: boolean;
                            borderColor: string;
                            click: {
                                metadata: {
                                    type: string;
                                    id: string;
                                }[];
                                actions: {
                                    type: string;
                                    publishText: string;
                                }[];
                            };
                        }[];
                        text?: undefined;
                    })[];
                }[];
                text?: undefined;
            } | {
                type: string;
                elements: ({
                    type: string;
                    title: string;
                    disabled: boolean;
                    click: {
                        actions: {
                            type: string;
                            submit: boolean;
                        }[];
                    };
                } | {
                    type: string;
                    title: string;
                    click: {
                        actions: {
                            type: string;
                            text: string;
                        }[];
                    };
                    disabled?: undefined;
                })[];
                text?: undefined;
            })[];
        };
    };
})[];
export declare function webScheduleSlotList(): ({
    type: string;
    text: string;
    channelData?: undefined;
} | {
    type: string;
    text: string;
    channelData: {
        metadata: any[];
        structuredContent: {
            type: string;
            border: string;
            elements: ({
                type: string;
                borderLine: boolean;
                elements: {
                    type: string;
                    elements: ({
                        type: string;
                        text: string;
                        tooltip: string;
                        style: {
                            bold: boolean;
                            size: string;
                        };
                    } | {
                        type: string;
                        text: string;
                        tooltip: string;
                        style?: undefined;
                    })[];
                }[];
                tooltip?: undefined;
                title?: undefined;
                class?: undefined;
                style?: undefined;
                click?: undefined;
            } | {
                type: string;
                tooltip: string;
                title: string;
                class: string;
                style: {
                    "background-color": string;
                    color: string;
                    "border-radius": number;
                    "border-color": string;
                    size: string;
                    bold: boolean;
                };
                click: {
                    actions: {
                        type: string;
                        title: string;
                        firstDayOfTheWeek: string;
                        slots: {
                            type: string;
                            id: string;
                            start: number;
                            end: number;
                            title: string;
                            description: string;
                            imageUrl: string;
                        }[];
                    }[];
                };
                borderLine?: undefined;
                elements?: undefined;
            })[];
            quickReplies?: undefined;
            message?: undefined;
        };
    };
} | {
    type: string;
    text: string;
    channelData: {
        metadata: any[];
        structuredContent: {
            quickReplies: {
                type: string;
                itemsPerRow: number;
                replies: {
                    click: {
                        actions: {
                            text: string;
                            type: string;
                        }[];
                    };
                    title: string;
                    tooltip: string;
                    type: string;
                }[];
            };
            message: string;
            type?: undefined;
            border?: undefined;
            elements?: undefined;
        };
    };
})[];
export declare function welcome(): ({
    type: string;
    text: string;
    channelData?: undefined;
} | {
    type: string;
    text: string;
    channelData: {
        metadata: any[];
        structuredContent: {
            quickReplies: {
                type: string;
                itemsPerRow: number;
                replies: {
                    type: string;
                    tooltip: string;
                    title: string;
                    click: {
                        actions: {
                            type: string;
                            text: string;
                        }[];
                        metadata: any[];
                    };
                }[];
            };
            message: string;
        };
    };
})[];
export declare function whatsAppReplyButton(): ({
    type: string;
    text: string;
    channelData?: undefined;
} | {
    type: string;
    text: string;
    channelData: {
        metadata: any[];
        structuredContent: {
            type: string;
            tag: string;
            elements: ({
                type: string;
                url: string;
                text?: undefined;
                tag?: undefined;
                title?: undefined;
                click?: undefined;
            } | {
                type: string;
                text: string;
                tag: string;
                url?: undefined;
                title?: undefined;
                click?: undefined;
            } | {
                type: string;
                title: string;
                click: {
                    actions: {
                        type: string;
                        text: string;
                    }[];
                };
                url?: undefined;
                text?: undefined;
                tag?: undefined;
            })[];
        };
    };
})[];
